
import { Pool } from '@neondatabase/serverless';
import * as dotenv from 'dotenv';

dotenv.config();

async function analyzeAuditLogs() {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const client = await pool.connect();

  try {
    console.log('Analyzing audit log distribution across clinics...\n');

    const result = await client.query(`
      SELECT 
        COALESCE(clinic_id, 'no_clinic') as clinic_id,
        COUNT(*) AS log_count
      FROM 
        audit_logs
      GROUP BY 
        clinic_id
      ORDER BY 
        log_count DESC;
    `);

    console.table(result.rows);
    
  } catch (error) {
    console.error('Error analyzing audit logs:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

analyzeAuditLogs().catch(console.error);
