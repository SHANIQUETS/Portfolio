// Script to remove existing patients and create test patients
import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import { faker } from '@faker-js/faker';
import { v4 as uuidv4 } from 'uuid';

// Import WebSocket for Neon DB
import WebSocket from 'ws';

// Configure Neon DB to use WebSocket
import { neonConfig } from '@neondatabase/serverless';
neonConfig.webSocketConstructor = WebSocket;

// Connect to the database
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

async function clearData() {
  try {
    console.log("Clearing existing data...");
    
    // Drop all tables in the correct order to maintain referential integrity
    await pool.query('DELETE FROM audit_logs');
    console.log("- Audit logs cleared");
    
    await pool.query('DELETE FROM medical_records');
    console.log("- Medical records cleared");
    
    await pool.query('DELETE FROM appointments');
    console.log("- Appointments cleared");
    
    await pool.query('DELETE FROM patients');
    console.log("- Patients cleared");
    
    // Reset sequences
    await pool.query("SELECT setval('patients_id_seq', 1, false)");
    await pool.query("SELECT setval('medical_records_id_seq', 1, false)");
    await pool.query("SELECT setval('appointments_id_seq', 1, false)");
    await pool.query("SELECT setval('audit_logs_id_seq', 1, false)");
    console.log("- Sequences reset");
    
    console.log("All data cleared successfully!");
  } catch (error) {
    console.error("Error clearing data:", error);
    throw error;
  }
}

// Jamaican parishes for realistic data
const JAMAICA_PARISHES = [
  "clarendon", "hanover", "kingston", "manchester", "portland", 
  "standrews", "stann", "stcatherine", "stelizabeth", "stjames", 
  "stmary", "stthomas", "trelawny", "westmoreland"
];

// Blood types
const BLOOD_TYPES = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-", "unknown"];

// Marital statuses
const MARITAL_STATUSES = ["single", "married", "divorced", "widowed", "separated", "other"];

// Gender options
const GENDERS = ["male", "female", "other"];

// Organ donor statuses
const ORGAN_DONOR_STATUSES = ["yes", "no", "unknown"];

// Insurance providers in Jamaica
const INSURANCE_PROVIDERS = [
  "Sagicor Life Jamaica", 
  "Guardian Life Limited", 
  "BCIC", 
  "GK Insurance", 
  "Jamaica National General Insurance", 
  "NCB Insurance", 
  "Scotia Jamaica Life Insurance", 
  "CUNA Caribbean Insurance Jamaica Ltd.",
  "Medecus Health"
];

// Common occupations in Jamaica
const OCCUPATIONS = [
  "Teacher", 
  "Farmer", 
  "Fisherman", 
  "Tourism Worker", 
  "Hotel Staff", 
  "Call Center Agent", 
  "Civil Servant", 
  "Nurse", 
  "Driver", 
  "Retail Worker", 
  "Tradesperson", 
  "Business Owner", 
  "Chef", 
  "Police Officer", 
  "Engineer", 
  "Doctor", 
  "Lawyer", 
  "Accountant", 
  "Student",
  "Retired"
];

// Jamaican cities and towns by parish
const JAMAICAN_CITIES = {
  "clarendon": ["May Pen", "Chapelton", "Lionel Town", "Rock River", "Milk River"],
  "hanover": ["Lucea", "Green Island", "Hopewell", "Sandy Bay", "Cascade"],
  "kingston": ["Kingston", "Harbour View", "Bull Bay"],
  "manchester": ["Mandeville", "Christiana", "Porus", "Mile Gully", "Newport"],
  "portland": ["Port Antonio", "Buff Bay", "Hope Bay", "Manchioneal"],
  "standrews": ["Half Way Tree", "Papine", "Gordon Town", "Mavis Bank", "Irish Town"],
  "stann": ["St. Ann's Bay", "Ocho Rios", "Brown's Town", "Runaway Bay", "Discovery Bay"],
  "stcatherine": ["Spanish Town", "Portmore", "Old Harbour", "Linstead", "Ewarton"],
  "stelizabeth": ["Santa Cruz", "Black River", "Junction", "Balaclava", "Malvern"],
  "stjames": ["Montego Bay", "Falmouth", "Cambridge", "Anchovy", "Reading"],
  "stmary": ["Port Maria", "Annotto Bay", "Highgate", "Oracabessa", "Gayle"],
  "stthomas": ["Morant Bay", "Yallahs", "Golden Grove", "Bath", "Seaforth"],
  "trelawny": ["Falmouth", "Ulster Spring", "Duncans", "Clark's Town", "Albert Town"],
  "westmoreland": ["Savanna-la-Mar", "Negril", "Whitehouse", "Grange Hill", "Petersfield"]
};

function getRandomJamaicanDate(minAge = 0, maxAge = 100) {
  // Get current date
  const now = new Date();
  
  // Calculate min and max birth years
  const minYear = now.getFullYear() - maxAge;
  const maxYear = now.getFullYear() - minAge;
  
  // Generate random birth year within range
  const year = faker.number.int({ min: minYear, max: maxYear });
  
  // Generate random month (0-11) and day (1-28/30/31 depending on month)
  const month = faker.number.int({ min: 0, max: 11 });
  
  // Simplified approach for days in month
  let daysInMonth = 31;
  if ([3, 5, 8, 10].includes(month)) daysInMonth = 30;
  else if (month === 1) {
    // February - simplified handling of leap years
    daysInMonth = ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) ? 29 : 28;
  }
  
  const day = faker.number.int({ min: 1, max: daysInMonth });
  
  // Format as DD/MM/YYYY (Jamaican format)
  return `${day.toString().padStart(2, '0')}/${(month + 1).toString().padStart(2, '0')}/${year}`;
}

function generatePhoneNumber() {
  // Jamaican phone numbers typically start with 876 (area code) followed by 7 digits
  return `876${faker.string.numeric(7)}`;
}

function generatePatientId() {
  // Format PT-XXXX where XXXX is a random 4-digit number
  return `PT-${faker.number.int({ min: 1000, max: 9999 })}`;
}

function generateBirthCertificateNumber() {
  // Some patients may not have a birth certificate number
  if (faker.number.int({ min: 1, max: 10 }) <= 2) {
    return null;
  }
  
  // Format: Letter followed by 5-6 digits
  const letter = faker.string.alpha({ count: 1, casing: 'upper' });
  const digits = faker.string.numeric(faker.number.int({ min: 5, max: 6 }));
  return `${letter}${digits}`;
}

function getRandomItem(array) {
  return array[Math.floor(Math.random() * array.length)];
}

function createTestPatient() {
  const gender = getRandomItem(GENDERS);
  const firstName = gender === 'male' ? faker.person.firstName('male') : faker.person.firstName('female');
  const lastName = faker.person.lastName();
  const parish = getRandomItem(JAMAICA_PARISHES);
  const city = getRandomItem(JAMAICAN_CITIES[parish] || ['Unknown']);
  
  // Age distribution: mostly adults, some children and elderly
  let minAge = 0, maxAge = 90;
  const ageGroup = faker.number.int({ min: 1, max: 10 });
  
  if (ageGroup <= 6) { // 60% adults (18-65)
    minAge = 18;
    maxAge = 65;
  } else if (ageGroup <= 8) { // 20% seniors (65-90)
    minAge = 65;
    maxAge = 90;
  } else { // 20% children/youth (0-18)
    minAge = 0;
    maxAge = 18;
  }
  
  const dateOfBirth = getRandomJamaicanDate(minAge, maxAge);
  
  // Height in cm (average adult height with some variation)
  let height;
  if (minAge < 18) {
    // Children's height varies more by age
    height = faker.number.int({ min: 50, max: 170 }).toString();
  } else {
    // Adult height
    height = gender === 'male' 
      ? faker.number.int({ min: 160, max: 190 }).toString() 
      : faker.number.int({ min: 150, max: 180 }).toString();
  }
  
  // Weight in lbs with reasonable distribution
  let weight;
  if (minAge < 18) {
    // Children's weight varies more by age
    weight = faker.number.int({ min: 10, max: 150 }).toString();
  } else {
    // Adult weight in pounds (not kg)
    weight = faker.number.int({ min: 100, max: 250 }).toString();
  }
  
  return {
    patientId: generatePatientId(),
    birthCertificateNumber: generateBirthCertificateNumber(),
    firstName,
    lastName,
    dateOfBirth,
    gender,
    occupation: minAge < 18 ? 'Student' : getRandomItem(OCCUPATIONS),
    maritalStatus: minAge < 18 ? 'single' : getRandomItem(MARITAL_STATUSES),
    organDonorStatus: getRandomItem(ORGAN_DONOR_STATUSES),
    bloodType: getRandomItem(BLOOD_TYPES),
    primaryPhysicianName: `Dr. ${faker.person.lastName()}`,
    
    // Contact information
    email: faker.internet.email({ firstName, lastName }),
    phone: generatePhoneNumber(),
    
    // Address
    addressLine1: faker.location.streetAddress(),
    city,
    parish,
    country: 'Jamaica',
    
    // Physical measurements
    height,
    weight,
    
    // Emergency contact (80% have emergency contacts)
    emergencyContactName: faker.number.int({ min: 1, max: 10 }) <= 8 ? faker.person.fullName() : null,
    emergencyContactRelationship: faker.number.int({ min: 1, max: 10 }) <= 8 ? getRandomItem(['Spouse', 'Parent', 'Child', 'Sibling', 'Friend']) : null,
    emergencyContactPhone: faker.number.int({ min: 1, max: 10 }) <= 8 ? generatePhoneNumber() : null,
    
    // Insurance (70% have insurance)
    insuranceProvider: faker.number.int({ min: 1, max: 10 }) <= 7 ? getRandomItem(INSURANCE_PROVIDERS) : null,
    insurancePolicyNumber: faker.number.int({ min: 1, max: 10 }) <= 7 ? `POL-${faker.string.alphanumeric(8).toUpperCase()}` : null,
    insuranceGroupNumber: faker.number.int({ min: 1, max: 10 }) <= 7 ? faker.string.numeric(5) : null,
    insuranceContactNumber: faker.number.int({ min: 1, max: 10 }) <= 7 ? generatePhoneNumber() : null,
  };
}

async function createTestPatients(count) {
  try {
    console.log(`Creating ${count} test patients...`);
    
    for (let i = 0; i < count; i++) {
      const patient = createTestPatient();
      
      // Insert into database
      await pool.query(`
        INSERT INTO patients (
          patient_id, birth_certificate_number, first_name, last_name, 
          date_of_birth, gender, occupation, marital_status, 
          organ_donor_status, blood_type, primary_physician_name, 
          email, phone, address_line1, city, parish, country,
          height, weight, emergency_contact_name, 
          emergency_contact_relationship, emergency_contact_phone,
          insurance_provider, insurance_policy_number, 
          insurance_group_number, insurance_contact_number
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14,
          $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26
        )
      `, [
        patient.patientId, patient.birthCertificateNumber, patient.firstName, patient.lastName,
        patient.dateOfBirth, patient.gender, patient.occupation, patient.maritalStatus,
        patient.organDonorStatus, patient.bloodType, patient.primaryPhysicianName,
        patient.email, patient.phone, patient.addressLine1, patient.city, patient.parish, patient.country,
        patient.height, patient.weight, patient.emergencyContactName,
        patient.emergencyContactRelationship, patient.emergencyContactPhone,
        patient.insuranceProvider, patient.insurancePolicyNumber,
        patient.insuranceGroupNumber, patient.insuranceContactNumber
      ]);
      
      if ((i + 1) % 10 === 0) {
        console.log(`- Created ${i + 1} patients`);
      }
    }
    
    console.log(`Successfully created ${count} test patients!`);
  } catch (error) {
    console.error("Error creating test patients:", error);
    throw error;
  }
}

async function main() {
  try {
    // Clear existing data
    await clearData();
    
    // Create test patients
    await createTestPatients(50);
    
    console.log("All operations completed successfully!");
    process.exit(0);
  } catch (error) {
    console.error("Script failed:", error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

main();