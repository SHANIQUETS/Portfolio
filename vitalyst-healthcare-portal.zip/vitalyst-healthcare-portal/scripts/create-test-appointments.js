// Script to create test appointments
import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import { faker } from '@faker-js/faker';

// Import WebSocket for Neon DB
import WebSocket from 'ws';

// Configure Neon DB to use WebSocket
import { neonConfig } from '@neondatabase/serverless';
neonConfig.webSocketConstructor = WebSocket;

// Connect to the database
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

// Appointment types
const APPOINTMENT_TYPES = [
  "Annual Physical",
  "Follow-up",
  "Urgent Care",
  "Consultation",
  "Lab Results Review",
  "Vaccination",
  "Pre-operation",
  "Post-operation",
  "Prenatal Care",
  "Child Wellness",
  "Diabetes Management",
  "Hypertension Checkup",
  "Dermatology",
  "Mental Health",
  "Pain Management",
  "Gynecology",
  "Cardiology",
  "Neurology",
  "Orthopedics",
  "ENT"
];

// Status types
const STATUS_TYPES = [
  "scheduled",
  "confirmed",
  "completed",
  "cancelled",
  "no-show",
  "rescheduled"
];

// Time slots - 30-minute appointments from 8:00 AM to 5:30 PM
const TIME_SLOTS = [
  "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
  "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30",
  "16:00", "16:30", "17:00", "17:30"
];

/**
 * Generate a date formatted as YYYY-MM-DD
 * @param {Date} date - The date to format
 * @returns {string} - Formatted date string
 */
function formatDate(date) {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${year}-${month}-${day}`;
}

/**
 * Get a random item from an array
 */
function getRandomItem(array) {
  return array[Math.floor(Math.random() * array.length)];
}

/**
 * Generate a random date within a specified range
 * @param {number} startDays - Days before/after today for start of range
 * @param {number} endDays - Days before/after today for end of range
 * @returns {Date} - Random date in the range
 */
function getRandomDate(startDays, endDays) {
  const today = new Date();
  const startDate = new Date(today);
  startDate.setDate(startDate.getDate() + startDays);
  
  const endDate = new Date(today);
  endDate.setDate(endDate.getDate() + endDays);
  
  return new Date(
    startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime())
  );
}

/**
 * Generate appointment data
 * @param {Array} patients - Array of patient IDs
 * @param {Array} doctors - Array of doctor IDs
 */
function generateAppointmentData(patientId, doctorId) {
  // Determine if this is a past, today, or future appointment
  let appointmentDate;
  let status;
  const appointmentType = Math.random() * 10;
  
  if (appointmentType < 4) { // 40% past appointments
    appointmentDate = getRandomDate(-90, -1);
    // Past appointments are either completed, cancelled, or no-show
    status = Math.random() > 0.2 ? "completed" : (Math.random() > 0.5 ? "cancelled" : "no-show");
  } else if (appointmentType < 5) { // 10% today's appointments
    appointmentDate = new Date();
    // Today's appointments are either scheduled, confirmed, or completed
    status = Math.random() > 0.7 ? "completed" : (Math.random() > 0.5 ? "confirmed" : "scheduled");
  } else { // 50% future appointments
    appointmentDate = getRandomDate(1, 60);
    // Future appointments are either scheduled or confirmed
    status = Math.random() > 0.3 ? "scheduled" : "confirmed";
  }
  
  return {
    patientId,
    doctorId,
    date: formatDate(appointmentDate),
    time: getRandomItem(TIME_SLOTS),
    type: getRandomItem(APPOINTMENT_TYPES),
    notes: faker.lorem.sentences({ min: 1, max: 3 }),
    status
  };
}

/**
 * Create test appointments
 */
async function createTestAppointments(count) {
  try {
    console.log(`Creating ${count} test appointments...`);
    
    // Get patient IDs
    const patientResult = await pool.query('SELECT id FROM patients');
    const patientIds = patientResult.rows.map(row => parseInt(row.id));
    
    // Get doctor IDs
    const doctorResult = await pool.query('SELECT id FROM users WHERE role = \'doctor\'');
    const doctorIds = doctorResult.rows.map(row => parseInt(row.id));
    
    if (doctorIds.length === 0) {
      throw new Error("No doctors found in the system");
    }
    
    for (let i = 0; i < count; i++) {
      // Choose a random patient and doctor
      const patientId = getRandomItem(patientIds);
      const doctorId = getRandomItem(doctorIds);
      
      // Generate appointment data
      const appointment = generateAppointmentData(patientId, doctorId);
      
      // Insert appointment
      await pool.query(`
        INSERT INTO appointments (
          patient_id, doctor_id, appointment_date, appointment_time, reason, notes, status, duration
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8
        )
      `, [
        appointment.patientId,
        appointment.doctorId,
        appointment.date,
        appointment.time,
        appointment.type,
        appointment.notes,
        appointment.status,
        30 // Default 30-minute appointment duration
      ]);
      
      if ((i + 1) % 10 === 0) {
        console.log(`- Created ${i + 1} appointments`);
      }
    }
    
    console.log(`Successfully created ${count} test appointments!`);
  } catch (error) {
    console.error("Error creating test appointments:", error);
    throw error;
  }
}

/**
 * Create appointments for today for specific patients to ensure we have test data showing up
 */
async function createTodayAppointments() {
  try {
    console.log("Creating appointments for today...");
    
    // Get first 5 patients
    const patientResult = await pool.query('SELECT id FROM patients LIMIT 5');
    const patientIds = patientResult.rows.map(row => parseInt(row.id));
    
    // Get doctor IDs
    const doctorResult = await pool.query('SELECT id FROM users WHERE role = \'doctor\'');
    const doctorIds = doctorResult.rows.map(row => parseInt(row.id));
    
    if (doctorIds.length === 0) {
      throw new Error("No doctors found in the system");
    }
    
    // Today's date in DD/MM/YYYY format
    const today = new Date();
    const formattedDate = formatDate(today);
    
    // Distribute throughout the day
    const specificTimes = ["09:00", "10:30", "13:00", "14:30", "16:00"];
    
    for (let i = 0; i < Math.min(patientIds.length, 5); i++) {
      const patientId = patientIds[i];
      const doctorId = getRandomItem(doctorIds);
      const time = specificTimes[i % specificTimes.length];
      const type = getRandomItem(APPOINTMENT_TYPES);
      const status = "confirmed";
      const notes = "Priority appointment for today";
      
      await pool.query(`
        INSERT INTO appointments (
          patient_id, doctor_id, appointment_date, appointment_time, reason, notes, status, duration
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8
        )
      `, [patientId, doctorId, formattedDate, time, type, notes, status, 30]);
    }
    
    console.log("Successfully created today's appointments!");
  } catch (error) {
    console.error("Error creating today's appointments:", error);
    throw error;
  }
}

/**
 * Main function
 */
async function main() {
  try {
    // Clear existing appointments
    await pool.query('DELETE FROM appointments');
    await pool.query("SELECT setval('appointments_id_seq', 1, false)");
    console.log("Existing appointments cleared");
    
    // Create random appointments
    await createTestAppointments(40);
    
    // Create specific appointments for today
    await createTodayAppointments();
    
    console.log("All appointments created successfully!");
    process.exit(0);
  } catch (error) {
    console.error("Script failed:", error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

main();