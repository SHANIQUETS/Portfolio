/**
 * Healthcare App Permission Rules for Clerks
 * HIPAA and UK GDPR Compliant Access Controls
 *
 * This module implements strict role-based access control to ensure clerks
 * only have access to appropriate patient information based on regulatory requirements.
 */

// Define the available user roles in the system
const ROLES = {
  CLERK: 'clerk',
  NURSE: 'nurse',
  DOCTOR: 'doctor',
  ADMIN: 'admin'
};

// Define resource categories by sensitivity level
const RESOURCE_TYPES = {
  // Accessible by clerks
  DEMOGRAPHICS: 'demographics',     // Basic patient information
  APPOINTMENTS: 'appointments',     // Scheduling information
  INSURANCE: 'insurance',           // Insurance and billing data
  
  // Restricted from clerks
  MEDICAL_RECORDS: 'medical_records',  // Full patient medical history
  DIAGNOSES: 'diagnoses',              // Clinical diagnoses
  TREATMENTS: 'treatments',            // Treatment plans
  LAB_RESULTS: 'lab_results',          // Test results
  MENTAL_HEALTH: 'mental_health',      // Mental health information
  NOTES: 'notes'                       // Clinical notes
};

/**
 * Maps which resources each role can access
 * Implements the principle of least privilege
 * 
 * This permission matrix explicitly defines what each role can access
 * Clerks have the most limited access for HIPAA/GDPR compliance
 */
const rolePermissions = {
  // Clerks can only access administrative data, not clinical data
  [ROLES.CLERK]: [
    RESOURCE_TYPES.DEMOGRAPHICS,
    RESOURCE_TYPES.APPOINTMENTS,
    RESOURCE_TYPES.INSURANCE,
    RESOURCE_TYPES.LAB_RESULTS,
    'results'
  ],
  
  // Nurses have broader access but still limited
  [ROLES.NURSE]: [
    RESOURCE_TYPES.DEMOGRAPHICS,
    RESOURCE_TYPES.APPOINTMENTS, 
    RESOURCE_TYPES.INSURANCE,
    RESOURCE_TYPES.MEDICAL_RECORDS,
    RESOURCE_TYPES.DIAGNOSES,
    RESOURCE_TYPES.TREATMENTS,
    RESOURCE_TYPES.LAB_RESULTS,
    RESOURCE_TYPES.NOTES
  ],
  
  // Doctors have full access to all resource types
  [ROLES.DOCTOR]: [
    RESOURCE_TYPES.DEMOGRAPHICS,
    RESOURCE_TYPES.APPOINTMENTS,
    RESOURCE_TYPES.INSURANCE,
    RESOURCE_TYPES.MEDICAL_RECORDS,
    RESOURCE_TYPES.DIAGNOSES,
    RESOURCE_TYPES.TREATMENTS, 
    RESOURCE_TYPES.LAB_RESULTS,
    RESOURCE_TYPES.MENTAL_HEALTH,
    RESOURCE_TYPES.NOTES
  ],
  
  // Admins have administrative access but limited clinical access
  [ROLES.ADMIN]: [
    RESOURCE_TYPES.DEMOGRAPHICS,
    RESOURCE_TYPES.APPOINTMENTS,
    RESOURCE_TYPES.INSURANCE
  ]
};

/**
 * Maps API endpoints to resource types
 * This allows the permission system to determine which resource
 * is being accessed for any given API request
 */
const endpointToResourceMap = {
  // Demographic endpoints - clerk accessible
  '/api/patients': RESOURCE_TYPES.DEMOGRAPHICS,
  '/api/patients/search': RESOURCE_TYPES.DEMOGRAPHICS,
  '/api/patients/lookup': RESOURCE_TYPES.DEMOGRAPHICS,
  
  // Appointment endpoints - clerk accessible
  '/api/appointments': RESOURCE_TYPES.APPOINTMENTS,
  '/api/schedule': RESOURCE_TYPES.APPOINTMENTS,
  
  // Insurance endpoints - clerk accessible
  '/api/billing': RESOURCE_TYPES.INSURANCE,
  '/api/insurance': RESOURCE_TYPES.INSURANCE,
  
  // Medical record endpoints - restricted from clerks
  '/api/medical-records': RESOURCE_TYPES.MEDICAL_RECORDS,
  '/api/patients/*/medical-records': RESOURCE_TYPES.MEDICAL_RECORDS,
  '/api/records': RESOURCE_TYPES.MEDICAL_RECORDS,
  
  // Clinical data endpoints - restricted from clerks
  '/api/diagnoses': RESOURCE_TYPES.DIAGNOSES,
  '/api/treatments': RESOURCE_TYPES.TREATMENTS,
  '/api/lab-results': RESOURCE_TYPES.LAB_RESULTS,
  '/api/mental-health': RESOURCE_TYPES.MENTAL_HEALTH,
  '/api/clinical-notes': RESOURCE_TYPES.NOTES
};

/**
 * Determines if a user can access a specific resource based on their role
 * 
 * @param {string} userRole - The role of the user (clerk, nurse, doctor, admin)
 * @param {string} resourceType - The type of resource being accessed
 * @returns {boolean} - True if the user has permission, false otherwise
 */
function canAccess(userRole, resourceType) {
  // If role doesn't exist, deny access
  if (!rolePermissions[userRole]) {
    return false;
  }
  
  // Check if this resource type is in the allowed list for this role
  return rolePermissions[userRole].includes(resourceType);
}

/**
 * Gets the resource type being accessed from an API endpoint
 * Supports both exact matches and pattern matching with wildcards
 * 
 * @param {string} endpoint - The API endpoint being accessed
 * @returns {string|null} - The resource type or null if not mapped
 */
function getResourceTypeForEndpoint(endpoint) {
  // First try exact match
  if (endpointToResourceMap[endpoint]) {
    return endpointToResourceMap[endpoint];
  }
  
  // If no exact match, try pattern matching for endpoints with parameters
  for (const [pattern, resourceType] of Object.entries(endpointToResourceMap)) {
    // Convert wildcard pattern to regex
    if (pattern.includes('*')) {
      const regexPattern = new RegExp('^' + pattern.replace('*', '[^/]+') + '$');
      if (regexPattern.test(endpoint)) {
        return resourceType;
      }
    }
  }
  
  // No match found
  return null;
}

/**
 * Express middleware to enforce clerk permissions
 * This function should be applied to routes that require permission checks
 * 
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
function enforceClerkPermissions(req, res, next) {
  const userRole = req.user?.role;
  
  // If no user or no role, deny access
  if (!userRole) {
    return res.status(401).json({
      error: 'Authentication required',
      message: 'You must be logged in to access this resource'
    });
  }
  
  // Get the resource type for this endpoint
  const resourceType = getResourceTypeForEndpoint(req.path);
  
  // If endpoint is not mapped, log warning and allow (though this should be avoided)
  if (!resourceType) {
    console.warn(`Warning: Unmapped endpoint ${req.path} in permission system`);
    return next();
  }
  
  // Check if this role can access this resource
  if (canAccess(userRole, resourceType)) {
    // Log the access for audit purposes (HIPAA requirement)
    logAccess(req.user.id, userRole, req.method, req.path, resourceType);
    return next();
  }
  
  // If clerk is trying to access restricted data, deny with clear message
  if (userRole === ROLES.CLERK && 
      !rolePermissions[ROLES.CLERK].includes(resourceType)) {
    return res.status(403).json({
      error: 'Access Forbidden',
      message: 'Clerks are not authorized to access clinical data based on HIPAA and GDPR regulations. ' +
               'This restriction protects patient privacy and ensures regulatory compliance.'
    });
  }
  
  // For any other unauthorized access
  return res.status(403).json({
    error: 'Access Forbidden',
    message: 'You do not have permission to access this resource'
  });
}

/**
 * Logs access attempts for audit purposes
 * Required for HIPAA compliance
 * 
 * @param {string} userId - ID of the user
 * @param {string} role - Role of the user
 * @param {string} method - HTTP method used
 * @param {string} endpoint - API endpoint accessed
 * @param {string} resourceType - Type of resource accessed
 */
function logAccess(userId, role, method, endpoint, resourceType) {
  // In a real system, this would write to a secure audit log
  console.log(`[AUDIT] ${new Date().toISOString()} - User ${userId} (${role}) ${method} ${endpoint} - Resource: ${resourceType}`);
  
  // Critical accesses (like mental health data) would trigger additional logging
  const sensitiveResources = [RESOURCE_TYPES.MENTAL_HEALTH];
  if (sensitiveResources.includes(resourceType)) {
    console.log(`[SENSITIVE ACCESS ALERT] User ${userId} accessed ${resourceType}`);
    // In production, this might trigger a notification to compliance officers
  }
}

module.exports = {
  ROLES,
  RESOURCE_TYPES,
  canAccess,
  enforceClerkPermissions,
  getResourceTypeForEndpoint
};