
import Stripe from "stripe";
import { Request, Response } from "express";
import { raw } from "express";
import { storage } from "./storage";
import { createAuditLog } from "./audit";

// Initialize Stripe with secret key
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: "2022-11-15",
});

// Raw body parser middleware for Stripe webhooks
export const stripeWebhookMiddleware = raw({ type: 'application/json' });

export async function handleStripeWebhook(req: Request, res: Response) {
  const sig = req.headers['stripe-signature'];

  if (!sig) {
    return res.status(400).send('No signature found');
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET || ''
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err);
    return res.status(400).send('Webhook signature verification failed');
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        const clinicId = session.metadata?.clinicId;
        
        if (!clinicId) {
          throw new Error('No clinic ID found in session metadata');
        }

        // Update subscription status in database
        await storage.updateClinicSubscription(clinicId, {
          status: 'active',
          subscriptionId: session.subscription as string,
          customerId: session.customer as string
        });

        // Create audit log
        await createAuditLog(
          req,
          'update',
          'subscription',
          clinicId,
          `Subscription payment completed for clinic ${clinicId}`
        );

        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        const subscription = await stripe.subscriptions.retrieve(invoice.subscription as string);
        const clinicId = subscription.metadata.clinicId;

        if (!clinicId) {
          throw new Error('No clinic ID found in subscription metadata');
        }

        // Update subscription status in database
        await storage.updateClinicSubscription(clinicId, {
          status: 'payment_failed'
        });

        // Create audit log
        await createAuditLog(
          req,
          'update',
          'subscription',
          clinicId,
          `Subscription payment failed for clinic ${clinicId}`
        );

        break;
      }

      // Add more event handlers as needed
    }

    res.json({ received: true });
  } catch (err) {
    console.error('Error processing webhook:', err);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
}
