import { Express, Request, Response } from "express";
import { storage } from "./storage";
import { requireAdminOrSuperAdmin, requireSystemAdmin } from "./middleware/admin-middleware";
import { isPlatformOwnerOnly } from "./middleware/platform-owner-middleware";
import { createAuditLog, createStringIdAuditLog } from "./audit";
import * as clinicManagement from "./clinic-management.js";
import { pool, db } from "./db";
import { STRIPE_AMOUNT_IDS, CLINIC_TIER_PRICING } from "../client/src/lib/constants";
import { format } from 'date-fns';
import { eq } from "drizzle-orm";
import { platformAdmins } from "@shared/schema";
import crypto from "crypto";

/**
 * Register admin-specific API routes
 * Routes are protected by different middleware based on required access level:
 * - requireAdminOrSuperAdmin: Allows both system admins and clinic super admins
 * - requireSystemAdmin: Only allows system admins (platform administrators)
 */
export function registerAdminRoutes(app: Express) {
  const adminRouter = '/api/admin';
  const billingRouter = `${adminRouter}/billing`;
  const platformRouter = `${adminRouter}/platform-admins`;
  
  // Platform admin routes - system level access only
  app.get(platformRouter, requireSystemAdmin, async (req, res) => {
    try {
      const admins = await db.select().from(platformAdmins);
      res.json(admins);
    } catch (error) {
      console.error("Error fetching platform admins:", error);
      res.status(500).json({ message: "Error fetching platform admins" });
    }
  });

  // Get system statistics
  app.get(`${adminRouter}/stats`, requireAdminOrSuperAdmin, async (req: Request, res: Response) => {
    try {
      // If the user is a super_admin, only show stats for their clinic
      if (req.user?.role === 'super_admin' && req.user?.clinicId) {
        const clinicId = req.user.clinicId;
        
        // Get counts for this clinic only
        const userCount = await storage.getClinicUserCount(clinicId);
        const patientCount = await storage.getClinicPatientCount(clinicId);
        const appointmentCount = await storage.getClinicAppointmentCount(clinicId);
        const medicalRecordCount = await storage.getClinicMedicalRecordCount(clinicId);
        
        return res.status(200).json({
          users: userCount,
          patients: patientCount,
          appointments: appointmentCount,
          medicalRecords: medicalRecordCount,
          lastUpdated: new Date(),
          clinicId // Include clinic ID so the frontend knows it's filtered
        });
      }
      
      // For system admins, show all stats
      const userCount = await storage.getUserCount();
      const patientCount = await storage.getPatientCount();
      const appointmentCount = await storage.getAppointmentCount();
      const medicalRecordCount = await storage.getMedicalRecordCount();
      
      res.status(200).json({
        users: userCount,
        patients: patientCount,
        appointments: appointmentCount,
        medicalRecords: medicalRecordCount,
        lastUpdated: new Date()
      });
    } catch (error) {
      console.error("Error fetching admin statistics:", error);
      res.status(500).json({ error: "Failed to fetch system statistics" });
    }
  });

  // Get all users with their roles
  app.get(`${adminRouter}/users`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      // Don't send the password hash to the frontend
      const sanitizedUsers = users.map(({ password, ...rest }) => rest);
      res.status(200).json(sanitizedUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  // Get audit logs with pagination
  app.get(`${adminRouter}/audit-logs`, requireAdminOrSuperAdmin, async (req: Request, res: Response) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 50;
      
      // If the user is a super_admin, only show logs for their clinic
      if (req.user?.role === 'super_admin' && req.user?.clinicId) {
        const auditLogs = await storage.getAuditLogsForClinic({
          page,
          limit,
          clinicId: req.user.clinicId
        });
        
        return res.status(200).json(auditLogs);
      }
      
      // For system admins, only show system-level logs (clinic, user, role, system operations)
      if (req.user?.role === 'admin') {
        const systemLogs = await storage.getSystemAuditLogs({
          page,
          limit
        });
        
        return res.status(200).json(systemLogs);
      }
      
      // Fallback: show all logs (this shouldn't typically be reached due to middleware)
      const auditLogs = await storage.getAuditLogsWithUsernames({
        page,
        limit
      });
      
      res.status(200).json(auditLogs);
    } catch (error) {
      console.error("Error fetching audit logs:", error);
      res.status(500).json({ error: "Failed to fetch audit logs" });
    }
  });

  // Update user role
  app.patch(`${adminRouter}/users/:userId/role`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const { userId } = req.params;
      const { role } = req.body;
      
      if (!userId || !role) {
        return res.status(400).json({ error: "User ID and role are required" });
      }
      
      // Validate role is one of the valid roles
      const validRoles = ['clerk', 'nurse', 'doctor', 'admin', 'super_admin'];
      if (!validRoles.includes(role)) {
        return res.status(400).json({ error: "Invalid role specified" });
      }
      
      const updated = await storage.updateUserRole(parseInt(userId), role);
      
      if (!updated) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Create audit log for role change
      await storage.createAuditLog({
        userId: req.user?.id,
        action: "update",
        entityType: "user_role",
        entityId: parseInt(userId),
        details: `Changed user role to ${role}`,
        ipAddress: req.ip
      });
      
      res.status(200).json({ success: true, message: "User role updated successfully" });
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ error: "Failed to update user role" });
    }
  });

  // Get all clinics (system admin only)
  app.get(`${adminRouter}/clinics`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const clinics = await storage.getAllClinics();
      res.status(200).json(clinics);
    } catch (error) {
      console.error("Error fetching clinics:", error);
      res.status(500).json({ error: "Failed to fetch clinics" });
    }
  });
  
  // Create a new clinic (system admin only)
  app.post(`${adminRouter}/clinics`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const { 
        name, 
        tier, 
        superAdminName, 
        superAdminEmail, 
        password, 
        entityType,
        customPrice,
        planStartDate,
        addressLine1,
        parish,
        city,
        trnNumber,
        registrationNumber
      } = req.body;
      
      if (!name || !tier || !superAdminName || !superAdminEmail || !password) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      // Validate password (minimum 8 characters, at least one number and one special character)
      const passwordRegex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$/;
      if (!passwordRegex.test(password)) {
        return res.status(400).json({ 
          error: "Password must be at least 8 characters long and include at least one number and one special character"
        });
      }
      
      // Check if email is already in use
      const existingUser = await storage.getUserByUsername(superAdminEmail);
      if (existingUser) {
        return res.status(400).json({ error: "Email already in use" });
      }
      
      // We now have the clinic management module and pool imported at the top of the file
      
      // Build address from components if provided
      let address = null;
      if (addressLine1) {
        address = addressLine1;
        if (parish) address += `, ${parish}`;
        if (city) address += `, ${city}`;
      }
      
      // Create the clinic and super admin user
      const clinic = await clinicManagement.onboardClinic(pool, {
        name,
        tier,
        superAdminName,
        superAdminEmail,
        password,
        customPrice,
        planStartDate,
        address,
        trnNumber,
        registrationNumber,
        entityType: entityType || "clinic", // Pass through entity type, defaulting to "clinic"
        fromAdminContext: true // Flag to indicate this is from admin context and can set entityType
      });
      
      // Create an audit log for this system-level operation using the new string ID function
      try {
        console.log("Creating audit log for new clinic:", clinic.id, clinic.name, clinic.tier);
        await createStringIdAuditLog(
          req,
          "create",
          "clinic",
          clinic.id,
          `Created clinic: ${name} (${tier} tier) [ID: ${clinic.id}]`
        );
        console.log("Audit log created successfully");
        
        // Automatically create a subscription for the new clinic
        try {
          console.log("Creating subscription for new clinic:", clinic.id, clinic.tier);
          
          // Calculate the amount based on the tier
          let subscriptionAmount;
          let isCustomPricing = false;
          
          if (tier === 'enterprise') {
            subscriptionAmount = customPrice; // Enterprise has custom pricing
            isCustomPricing = true;
            
            if (!subscriptionAmount) {
              subscriptionAmount = 500; // Default enterprise price if not specified
            }
          } else {
            // Use the standard pricing for non-enterprise tiers
            const CLINIC_TIER_PRICING = {
              'sole_trader': 100,
              'small_clinic': 150,
              'standard_clinic': 200
            };
            subscriptionAmount = CLINIC_TIER_PRICING[tier] || 100;
          }
          
          // Use start date if provided, otherwise use current date
          const subscriptionStartDate = planStartDate ? new Date(planStartDate) : new Date();
          
          // Import stripe manager
          const stripeManager = await import('./stripe-manager.js');
          
          // Create a stripe customer
          const customerInfo = {
            name: superAdminName,
            email: superAdminEmail,
            clinicId: clinic.id
          };
          
          const customer = await stripeManager.createCustomer(customerInfo);
          
          // Create a subscription
          const subscription = await stripeManager.createSubscription({
            customerId: customer.id,
            tier,
            amount: subscriptionAmount,
            startDate: subscriptionStartDate
          });
          
          // Store the subscription in our database
          const subscriptionData = {
            clinicId: clinic.id,
            tier,
            amount: subscriptionAmount,
            isCustomPricing,
            startDate: subscriptionStartDate,
            status: 'active',
            stripeCustomerId: customer.id,
            stripeSubscriptionId: subscription.id,
            paymentMethodId: null
          };
          
          const createdSubscription = await storage.createSubscription(subscriptionData);
          
          // Create audit log for the subscription
          await createStringIdAuditLog(
            req,
            "create",
            "clinic_subscription",
            clinic.id,
            `Automatically created ${tier} subscription for new clinic`
          );
          
          console.log("Subscription created successfully for new clinic");
          
          // Automatically create an invoice for the first month
          try {
            console.log("Creating initial invoice for new clinic:", clinic.id);
            
            // Generate unique invoice number
            const invoiceNumber = `INV-${Math.floor(Math.random() * 1000000000)}`;
            
            // Set due date to 30 days from now
            const dueDate = new Date();
            dueDate.setDate(dueDate.getDate() + 30);
            
            // Create invoice data
            const invoiceData = {
              invoiceNumber,
              clinicId: clinic.id,
              subscriptionId: createdSubscription.id,
              amount: subscriptionAmount,
              description: `Initial subscription payment for ${name} (${tier} tier)`,
              status: 'sent', // Set as sent by default
              dueDate,
              issuedDate: new Date(),
              notes: 'Automatically generated on clinic registration'
            };
            
            // Create the invoice in the database
            const invoice = await storage.createInvoice(invoiceData);
            
            // Create audit log for the invoice
            await createStringIdAuditLog(
              req,
              "create",
              "invoice",
              clinic.id,
              `Automatically created invoice #${invoiceNumber} for clinic ${clinic.id} for $${subscriptionAmount}`
            );
            
            console.log("Initial invoice created successfully:", invoice.id);
          } catch (invoiceError) {
            console.error("Error creating initial invoice for new clinic:", invoiceError);
            // Don't fail the clinic creation if invoice creation fails
          }
        } catch (subscriptionError) {
          console.error("Error creating subscription for new clinic:", subscriptionError);
          // Don't fail the clinic creation if subscription creation fails
        }
      } catch (logError) {
        console.error("Error creating audit log:", logError);
        // We don't want to fail the whole operation if just the audit log fails
      }
      
      res.status(201).json({ 
        message: "Clinic created successfully", 
        clinic: { id: clinic.id, name: clinic.name, tier: clinic.tier } 
      });
    } catch (error: any) {
      console.error("Error creating clinic:", error);
      res.status(500).json({ error: `Failed to create clinic: ${error.message || 'Unknown error'}` });
    }
  });

  // Update clinic entity type (system admin only)
  app.patch(`${adminRouter}/clinics/:clinicId/entity-type`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const { clinicId } = req.params;
      const { entityType } = req.body;
      
      if (!clinicId || !entityType) {
        return res.status(400).json({ error: "Clinic ID and entity type are required" });
      }
      
      // Get the current entity type
      const currentEntityTypeResult = await pool.query(
        'SELECT entity_type FROM clinics WHERE id = $1',
        [clinicId]
      );
      
      if (currentEntityTypeResult.rows.length === 0) {
        return res.status(404).json({ error: "Clinic not found" });
      }
      
      const currentEntityType = currentEntityTypeResult.rows[0].entity_type;
      
      // Never allow changes to or from platform_admin for security reasons
      if (entityType === 'platform_admin' || currentEntityType === 'platform_admin') {
        return res.status(403).json({ 
          error: "Cannot change entity type of platform_admin entities. Platform Administration is a system entity that cannot be modified." 
        });
      }
      
      // Validate entity type is one of the allowed values
      const validEntityTypes = ['clinic'];
      if (!validEntityTypes.includes(entityType)) {
        return res.status(400).json({ error: "Invalid entity type specified" });
      }
      
      // Use the pool already imported at the top of the file
      
      // Update the entity type
      const result = await pool.query(
        'UPDATE clinics SET entity_type = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
        [entityType, clinicId]
      );
      
      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Clinic not found" });
      }
      
      // Create audit log for this sensitive system-level operation using string ID function
      await createStringIdAuditLog(
        req,
        "update",
        "clinic_entity_type",
        clinicId,
        `Changed clinic entity type to ${entityType}`
      );
      
      res.status(200).json({ 
        message: "Clinic entity type updated successfully", 
        clinic: result.rows[0]
      });
    } catch (error: any) {
      console.error("Error updating clinic entity type:", error);
      res.status(500).json({ error: `Failed to update entity type: ${error.message || 'Unknown error'}` });
    }
  });
  
  // Billing and Invoice Management (only System Administrators)
  
  // Get all invoices with pagination
  app.get(`${billingRouter}/invoices`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 50;
      
      const result = await storage.getAllInvoices({ page, limit });
      res.status(200).json(result);
    } catch (error) {
      console.error("Error fetching invoices:", error);
      res.status(500).json({ error: "Failed to fetch invoices" });
    }
  });
  
  // Get clinic-specific invoices
  app.get(`${billingRouter}/invoices/clinic/:clinicId`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const { clinicId } = req.params;
      
      if (!clinicId) {
        return res.status(400).json({ error: "Clinic ID is required" });
      }
      
      const invoices = await storage.getInvoicesByClinic(clinicId);
      res.status(200).json(invoices);
    } catch (error) {
      console.error("Error fetching clinic invoices:", error);
      res.status(500).json({ error: "Failed to fetch clinic invoices" });
    }
  });
  
  // Create a new invoice
  app.post(`${billingRouter}/invoices`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const { 
        clinicId, 
        subscriptionId,
        amount, 
        description, 
        dueDate, 
        issuedDate, 
        invoiceNumber 
      } = req.body;
      
      if (!clinicId || !amount || !dueDate || !issuedDate || !invoiceNumber) {
        return res.status(400).json({ 
          error: "Missing required fields", 
          required: "clinicId, amount, dueDate, issuedDate, invoiceNumber" 
        });
      }
      
      // Check if clinic exists
      const clinic = await storage.getClinic(clinicId);
      if (!clinic) {
        return res.status(404).json({ error: "Clinic not found" });
      }
      
      // Create the invoice
      const invoice = await storage.createInvoice({
        clinicId,
        subscriptionId,
        invoiceNumber,
        amount,
        description,
        status: "draft", // Start as draft
        dueDate: new Date(dueDate),
        issuedDate: new Date(issuedDate),
        paymentMethod: null,
        paymentLink: null,
        notes: null,
        paidDate: null
      });
      
      // Create audit log for invoice creation
      await createAuditLog(
        req,
        "create",
        "invoice",
        invoice.id,
        `Created invoice #${invoiceNumber} for clinic ${clinicId} for $${amount}`
      );
      
      res.status(201).json({
        message: "Invoice created successfully",
        invoice
      });
    } catch (error: any) {
      console.error("Error creating invoice:", error);
      res.status(500).json({ error: `Failed to create invoice: ${error.message || 'Unknown error'}` });
    }
  });
  
  // Update invoice status
  app.patch(`${billingRouter}/invoices/:invoiceId/status`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const { invoiceId } = req.params;
      const { status, paymentMethod, paymentLink, notes, paidDate } = req.body;
      
      if (!invoiceId || !status) {
        return res.status(400).json({ error: "Invoice ID and status are required" });
      }
      
      // Validate status is one of the allowed values
      const validStatuses = ['draft', 'sent', 'paid', 'overdue', 'cancelled'];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ error: "Invalid status specified" });
      }
      
      // Get the existing invoice
      const existingInvoice = await storage.getInvoice(parseInt(invoiceId));
      if (!existingInvoice) {
        return res.status(404).json({ error: "Invoice not found" });
      }
      
      // Prepare update data
      const updateData: any = { status };
      
      // Add optional fields if provided
      if (paymentMethod) updateData.paymentMethod = paymentMethod;
      if (paymentLink) updateData.paymentLink = paymentLink;
      if (notes) updateData.notes = notes;
      
      // Handle paid date specifically
      if (status === 'paid' && !paidDate) {
        // If status is changed to paid and no specific paid date is provided, use current date
        updateData.paidDate = new Date();
      } else if (paidDate) {
        // If a specific paid date is provided, use it
        updateData.paidDate = new Date(paidDate);
      }
      
      // Update the invoice
      const updatedInvoice = await storage.updateInvoice(parseInt(invoiceId), updateData);
      
      // Create audit log for status update
      await createAuditLog(
        req,
        "update",
        "invoice_status",
        parseInt(invoiceId),
        `Updated invoice #${existingInvoice.invoiceNumber} status to ${status}`
      );
      
      res.status(200).json({
        message: "Invoice status updated successfully",
        invoice: updatedInvoice
      });
    } catch (error: any) {
      console.error("Error updating invoice status:", error);
      res.status(500).json({ error: `Failed to update invoice status: ${error.message || 'Unknown error'}` });
    }
  });
  
  // Get a specific invoice
  app.get(`${billingRouter}/invoices/:invoiceId`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const { invoiceId } = req.params;
      
      if (!invoiceId) {
        return res.status(400).json({ error: "Invoice ID is required" });
      }
      
      const invoice = await storage.getInvoice(parseInt(invoiceId));
      
      if (!invoice) {
        return res.status(404).json({ error: "Invoice not found" });
      }
      
      res.status(200).json(invoice);
    } catch (error) {
      console.error("Error fetching invoice:", error);
      res.status(500).json({ error: "Failed to fetch invoice" });
    }
  });
  
  // Create a new subscription for a clinic (system admin only)
  app.post(`${billingRouter}/subscriptions`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const { clinicId, tier, amount, startDate, paymentMethodId } = req.body;
      
      if (!clinicId || !tier) {
        return res.status(400).json({ error: "Clinic ID and tier are required" });
      }
      
      // Check if subscription tier is valid
      if (!STRIPE_AMOUNT_IDS[tier] && tier !== 'enterprise') {
        return res.status(400).json({ error: "Invalid subscription tier" });
      }
      
      // Calculate the amount based on the tier
      let subscriptionAmount;
      let isCustomPricing = false;
      
      if (tier === 'enterprise') {
        subscriptionAmount = amount; // Enterprise has custom pricing
        isCustomPricing = true;
        
        if (!subscriptionAmount) {
          return res.status(400).json({ error: "Amount is required for enterprise tier" });
        }
      } else {
        subscriptionAmount = CLINIC_TIER_PRICING[tier];
      }
      
      // Use the specified start date or default to today
      const subscriptionStartDate = startDate ? new Date(startDate) : new Date();
      
      // MOCK STRIPE IMPLEMENTATION
      // In a real implementation, this is where we would call Stripe APIs
      
      // Import stripe manager and use it for customer and subscription creation
      const stripeManager = await import('./stripe-manager.js');
      
      // Create a stripe customer (mock for now)
      const customerInfo = {
        name: "Clinic Administrator",
        email: "clinic@example.com",
        clinicId
      };
      
      const customer = await stripeManager.createCustomer(customerInfo);
      
      // Create a stripe subscription (mock for now)
      const subscription = await stripeManager.createSubscription({
        customerId: customer.id,
        tier,
        amount: subscriptionAmount,
        startDate: subscriptionStartDate // Pass the start date to the Stripe manager
      });
      
      // Create a new subscription record in our database
      const subscriptionData = {
        clinicId,
        tier,
        amount: subscriptionAmount,
        isCustomPricing,
        startDate: subscriptionStartDate,
        status: 'active',
        stripeCustomerId: customer.id,
        stripeSubscriptionId: subscription.id,
        // Include payment method if provided
        paymentMethodId: paymentMethodId || null
      };
      
      const createdSubscription = await storage.createSubscription(subscriptionData);
      
      // Update the clinic's tier
      await pool.query(
        'UPDATE clinics SET tier = $1, updated_at = NOW() WHERE id = $2',
        [tier, clinicId]
      );
      
      // Create audit log for subscription creation using both methods
      // Standard audit log that includes the numeric subscription ID
      await createAuditLog(
        req,
        "create",
        "subscription",
        createdSubscription.id,
        `Created new ${tier} subscription (ID: ${createdSubscription.id})`
      );
      
      // String ID audit log that captures the clinic ID relationship
      await createStringIdAuditLog(
        req,
        "create",
        "clinic_subscription",
        clinicId,
        `Created new ${tier} subscription for clinic starting on ${format(subscriptionStartDate, 'yyyy-MM-dd')}`
      );
      
      res.status(201).json({
        message: "Subscription created successfully",
        subscription: createdSubscription
      });
    } catch (error: any) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ error: `Failed to create subscription: ${error.message || 'Unknown error'}` });
    }
  });
  
  // Get subscription for a clinic (system admin only)
  app.get(`${billingRouter}/clinic-subscription`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const { clinicId } = req.query;
      
      if (!clinicId) {
        return res.status(400).json({ error: "Clinic ID is required" });
      }
      
      console.log(`Fetching subscription for clinic ID: ${clinicId}`);
      const subscription = await storage.getSubscriptionByClinic(clinicId as string);
      
      if (!subscription) {
        return res.status(404).json({ error: "No subscription found for this clinic" });
      }
      
      res.status(200).json({ subscription });
    } catch (error: any) {
      console.error("Error fetching clinic subscription:", error);
      res.status(500).json({ error: `Failed to fetch subscription: ${error.message || 'Unknown error'}` });
    }
  });

  // Get system health and resource usage
  app.get(`${adminRouter}/health`, requireAdminOrSuperAdmin, (req: Request, res: Response) => {
    try {
      const health = {
        status: "ok",
        uptime: process.uptime(),
        timestamp: Date.now(),
        memory: process.memoryUsage(),
        cpuUsage: process.cpuUsage()
      };
      
      res.status(200).json(health);
    } catch (error) {
      console.error("Error fetching system health:", error);
      res.status(500).json({ error: "Failed to fetch system health information" });
    }
  });

  // ----------- Platform Admin System APIs -----------
  
  // Get all platform admins (system admin only)
  app.get(`${adminRouter}/platform-admins`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const admins = await db.select().from(platformAdmins);
      res.status(200).json(admins);
    } catch (error) {
      console.error("Error fetching platform admins:", error);
      res.status(500).json({ error: "Failed to fetch platform administrators" });
    }
  });

  // Get platform admin by ID (system admin only)
  app.get(`${adminRouter}/platform-admins/:id`, requireSystemAdmin, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const admin = await db.select()
        .from(platformAdmins)
        .where(eq(platformAdmins.id, id))
        .limit(1);
        
      if (!admin.length) {
        return res.status(404).json({ error: "Platform administrator not found" });
      }
      
      res.status(200).json(admin[0]);
    } catch (error) {
      console.error("Error fetching platform admin:", error);
      res.status(500).json({ error: "Failed to fetch platform administrator" });
    }
  });
  
  // Create a new platform admin (primary owner only)
  app.post(`${adminRouter}/platform-admins`, isPlatformOwnerOnly, async (req: Request, res: Response) => {
    try {
      const { email, name } = req.body;
      
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      
      // Check if email already exists
      const existingAdmin = await db.select()
        .from(platformAdmins)
        .where(eq(platformAdmins.email, email))
        .limit(1);
        
      if (existingAdmin.length > 0) {
        return res.status(400).json({ error: "A platform administrator with this email already exists" });
      }
      
      // Generate unique ID
      const id = crypto.randomUUID();
      
      // Create new platform admin
      await db.insert(platformAdmins).values({
        id,
        email,
        name: name || email.split('@')[0], // Use first part of email as name if not provided
        isPrimaryOwner: false, // Only the original admin should be primary
      });
      
      // Create audit log for this system-level operation
      await createAuditLog(
        req,
        "create",
        "platform_admin",
        undefined,
        `Created platform administrator for ${email}`
      );
      
      res.status(201).json({ 
        success: true, 
        message: "Platform administrator created successfully",
        id
      });
    } catch (error: any) {
      console.error("Error creating platform admin:", error);
      res.status(500).json({ error: `Failed to create platform administrator: ${error.message || 'Unknown error'}` });
    }
  });
  
  // Update a platform admin (primary owner only)
  app.patch(`${adminRouter}/platform-admins/:id`, isPlatformOwnerOnly, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { name, email } = req.body;
      
      // Check if admin exists
      const existingAdmin = await db.select()
        .from(platformAdmins)
        .where(eq(platformAdmins.id, id))
        .limit(1);
        
      if (!existingAdmin.length) {
        return res.status(404).json({ error: "Platform administrator not found" });
      }
      
      // Prepare update data
      const updateData: {name?: string; email?: string} = {};
      if (name !== undefined) updateData.name = name;
      if (email !== undefined) updateData.email = email;
      
      // If email is being updated, check it doesn't conflict
      if (email) {
        const emailExists = await db.select()
          .from(platformAdmins)
          .where(eq(platformAdmins.email, email))
          .limit(1);
          
        if (emailExists.length > 0 && emailExists[0].id !== id) {
          return res.status(400).json({ error: "Email already in use by another platform administrator" });
        }
      }
      
      // Update the admin
      await db.update(platformAdmins)
        .set(updateData)
        .where(eq(platformAdmins.id, id));
      
      // Create audit log
      await createAuditLog(
        req,
        "update",
        "platform_admin",
        undefined,
        `Updated platform administrator ${id}`
      );
      
      res.status(200).json({ 
        success: true, 
        message: "Platform administrator updated successfully" 
      });
    } catch (error: any) {
      console.error("Error updating platform admin:", error);
      res.status(500).json({ error: `Failed to update platform administrator: ${error.message || 'Unknown error'}` });
    }
  });
  
  // Delete a platform admin (primary owner only)
  app.delete(`${adminRouter}/platform-admins/:id`, isPlatformOwnerOnly, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      // Check if admin exists
      const existingAdmin = await db.select()
        .from(platformAdmins)
        .where(eq(platformAdmins.id, id))
        .limit(1);
        
      if (!existingAdmin.length) {
        return res.status(404).json({ error: "Platform administrator not found" });
      }
      
      // Safety check: cannot delete primary owner
      if (existingAdmin[0].isPrimaryOwner) {
        return res.status(403).json({ error: "Cannot delete the primary platform owner" });
      }
      
      // Delete the admin
      await db.delete(platformAdmins)
        .where(eq(platformAdmins.id, id));
      
      // Create audit log
      await createAuditLog(
        req,
        "delete",
        "platform_admin",
        undefined,
        `Deleted platform administrator ${id}`
      );
      
      res.status(200).json({ 
        success: true, 
        message: "Platform administrator deleted successfully" 
      });
    } catch (error: any) {
      console.error("Error deleting platform admin:", error);
      res.status(500).json({ error: `Failed to delete platform administrator: ${error.message || 'Unknown error'}` });
    }
  });
}