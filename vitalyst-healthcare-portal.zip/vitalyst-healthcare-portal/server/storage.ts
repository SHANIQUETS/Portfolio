import { 
  users, patients, medicalRecords, appointments, auditLogs, patientResults, clinics, invoices, subscriptions,
  type User, type InsertUser, 
  type Patient, type InsertPatient, 
  type MedicalRecord, type InsertMedicalRecord,
  type Appointment, type InsertAppointment,
  type AuditLog, type InsertAuditLog,
  type PatientResult, type InsertPatientResult,
  type Clinic, type InsertClinic,
  type Invoice, type InsertInvoice,
  type Subscription, type InsertSubscription
} from "@shared/schema";
import { count, sql, eq, or, ilike, inArray, isNull, and, desc } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db } from "./db";
import { pool } from "./db";
import Fuse from 'fuse.js';

const PostgresSessionStore = connectPg(session);

import { PotentialDuplicate } from "../shared/types";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserCount(): Promise<number>;
  getClinicUserCount(clinicId: string): Promise<number>;
  getDoctorsByClinic(clinicId: string): Promise<User[]>;

  // Patient operations
  getPatient(id: number): Promise<Patient | undefined>;
  getPatientByPatientId(patientId: string): Promise<Patient | undefined>;
  getAllPatients(): Promise<Patient[]>;
  createPatient(patient: InsertPatient): Promise<Patient>;
  updatePatient(id: number, patient: InsertPatient): Promise<Patient>;
  searchPatients(query: string): Promise<Patient[]>;
  lookupPatients(query: string): Promise<Patient[]>;
  fuzzySearchPatients(query: string): Promise<Patient[]>;
  findPotentialDuplicates(patient: InsertPatient | Patient): Promise<PotentialDuplicate[]>;
  mergePatients(sourceId: number, targetId: number): Promise<Patient>;
  getPatientCount(): Promise<number>;
  getClinicPatientCount(clinicId: string): Promise<number>;

  // Medical record operations
  getMedicalRecord(id: number): Promise<MedicalRecord | undefined>;
  getAllMedicalRecords(): Promise<MedicalRecord[]>;
  getPatientMedicalRecords(patientId: number): Promise<MedicalRecord[]>;
  createMedicalRecord(record: InsertMedicalRecord): Promise<MedicalRecord>;
  updateMedicalRecord(id: number, record: Partial<InsertMedicalRecord>): Promise<MedicalRecord>;
  getMedicalRecordCount(): Promise<number>;
  getClinicMedicalRecordCount(clinicId: string): Promise<number>;

  // Appointment operations
  getAppointment(id: number): Promise<Appointment | undefined>;
  getAllAppointments(): Promise<Appointment[]>;
  getPatientAppointments(patientId: number): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment>;
  getAppointmentCount(): Promise<number>;
  getClinicAppointmentCount(clinicId: string): Promise<number>;

  // Audit log operations
  createAuditLog(auditLog: InsertAuditLog): Promise<AuditLog>;
  getAuditLogs(limit?: number, offset?: number): Promise<(AuditLog & { username?: string })[]>;
  getAuditLogsByEntityType(entityType: string, entityId?: number): Promise<AuditLog[]>;
  getAuditLogsByUser(userId: number): Promise<AuditLog[]>;
  getAuditLogsWithUsernames(options: {page: number, limit: number}): Promise<{logs: (AuditLog & { username?: string })[], total: number}>;
  getAuditLogsForClinic(options: {page: number, limit: number, clinicId: string}): Promise<{logs: (AuditLog & { username?: string })[], total: number}>;

  // Patient result operations
  getPatientResult(id: number): Promise<PatientResult | undefined>;
  getAllPatientResults(): Promise<PatientResult[]>;
  getPatientResults(patientId: number): Promise<PatientResult[]>;
  createPatientResult(result: InsertPatientResult): Promise<PatientResult>;
  updatePatientResult(id: number, result: Partial<InsertPatientResult>): Promise<PatientResult>;
  deletePatientResult(id: number): Promise<void>;

  // Clinic operations
  getClinic(id: string): Promise<Clinic | undefined>;
  getAllClinics(): Promise<Clinic[]>;
  createClinic(clinic: InsertClinic): Promise<Clinic>;

  // Invoice operations
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  getInvoice(id: number): Promise<Invoice | undefined>;
  getInvoicesByClinic(clinicId: string): Promise<Invoice[]>;
  getAllInvoices(options?: {page: number, limit: number}): Promise<{invoices: Invoice[], total: number}>;
  updateInvoice(id: number, invoice: Partial<InsertInvoice>): Promise<Invoice>;

  // Subscription operations
  getSubscription(id: number): Promise<Subscription | undefined>;
  getSubscriptionByClinic(clinicId: string): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: number, subscription: Partial<InsertSubscription>): Promise<Subscription>;
  updateSubscriptionStripeInfo(id: number, stripeInfo: { stripeCustomerId: string, stripeSubscriptionId: string }): Promise<Subscription>;

  // Session store
  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    // Create session store with more explicit configuration
    console.log("Creating PostgreSQL session store");
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true,
      tableName: 'session',
      pruneSessionInterval: 60, // prune expired sessions every minute
      errorLog: console.error,
    });
    console.log("PostgreSQL session store created");
  }

  // Audit log methods
  async createAuditLog(insertAuditLog: InsertAuditLog): Promise<AuditLog> {
    const [log] = await db
      .insert(auditLogs)
      .values(insertAuditLog)
      .returning();
    return log;
  }

  async getAuditLogs(limit: number = 100, offset: number = 0): Promise<(AuditLog & { username?: string })[]> {
    const result = await db
      .select({
        ...auditLogs,
        username: users.username
      })
      .from(auditLogs)
      .leftJoin(users, eq(auditLogs.userId, users.id))
      .orderBy(auditLogs.timestamp, 'desc')
      .limit(limit)
      .offset(offset);
    return result;
  }

  async getAuditLogsByEntityType(entityType: string, entityId?: number): Promise<AuditLog[]> {
    let query = db
      .select()
      .from(auditLogs)
      .where(eq(auditLogs.entityType, entityType));

    if (entityId) {
      query = query.where(eq(auditLogs.entityId, entityId));
    }

    const result = await query.orderBy(auditLogs.timestamp, 'desc');
    return result;
  }

  async updateUser(id: number, updateData: Partial<User>): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  async getAuditLogsByUser(userId: number): Promise<AuditLog[]> {
    const result = await db
      .select()
      .from(auditLogs)
      .where(eq(auditLogs.userId, userId))
      .orderBy(auditLogs.timestamp, 'desc');
    return result;
  }

  async getAuditLogsWithUsernames({page = 1, limit = 50, clinicId}: {page: number, limit: number, clinicId?: string}): Promise<{logs: (AuditLog & { username?: string })[], total: number}> {
    const offset = (page - 1) * limit;

    // Build base query
    const baseQuery = db.select().from(auditLogs);
    if (clinicId) {
      baseQuery.where(eq(auditLogs.clinicId, clinicId));
    }

    // Get total count with clinic filter
    const [countResult] = await baseQuery.select({ count: count() });

    // Get logs with pagination and clinic filter
    const logs = await db
      .select({
        ...auditLogs,
        username: users.username
      })
      .from(auditLogs)
      .leftJoin(users, eq(auditLogs.userId, users.id))
      .where(clinicId ? eq(auditLogs.clinicId, clinicId) : undefined)
      .orderBy(desc(auditLogs.timestamp)) // Use desc() helper for consistent descending order
      .limit(limit)
      .offset(offset);

    return {
      logs,
      total: countResult.count
    };
  }

  // Get system-level audit logs for system admins
  async getSystemAuditLogs({page = 1, limit = 50}: {page: number, limit: number}): Promise<{logs: (AuditLog & { username?: string })[], total: number}> {
    const offset = (page - 1) * limit;

    try {
      // System-level operations generally involve these entity types
      const systemEntityTypes = ['clinic', 'user', 'user_role', 'role', 'system'];

      // Get admin user IDs
      const adminUsers = await db
        .select({
          id: users.id
        })
        .from(users)
        .where(eq(users.role, 'admin'));

      // If no admins found, return empty result
      if (adminUsers.length === 0) {
        return { logs: [], total: 0 };
      }

      // Extract user IDs
      const adminUserIds = adminUsers.map(user => user.id);

      // Get total count of system logs - Use proper Drizzle operators instead of raw SQL
      const [countResult] = await db
        .select({
          count: count()
        })
        .from(auditLogs)
        .where(
          or(
            inArray(auditLogs.entityType, systemEntityTypes),
            inArray(auditLogs.userId, adminUserIds)
          )
        );

      // Get system logs with pagination - Use proper Drizzle operators
      const logs = await db
        .select({
          id: auditLogs.id,
          userId: auditLogs.userId,
          action: auditLogs.action,
          entityType: auditLogs.entityType,
          entityId: auditLogs.entityId,
          details: auditLogs.details,
          ipAddress: auditLogs.ipAddress,
          timestamp: auditLogs.timestamp,
          username: users.username
        })
        .from(auditLogs)
        .leftJoin(users, eq(auditLogs.userId, users.id))
        .where(
          or(
            inArray(auditLogs.entityType, systemEntityTypes),
            inArray(auditLogs.userId, adminUserIds)
          )
        )
        .limit(limit)
        .offset(offset)
        .orderBy(auditLogs.timestamp, 'desc');

      return {
        logs,
        total: countResult.count
      };
    } catch (error) {
      console.error('Error in getSystemAuditLogs:', error);
      // Return empty result on error to prevent crashing
      return { logs: [], total: 0 };
    }
  }

  async getAuditLogsForClinic({page = 1, limit = 50, clinicId}: {page: number, limit: number, clinicId: string}): Promise<{logs: (AuditLog & { username?: string })[], total: number}> {
    const offset = (page - 1) * limit;

    // Get users who belong to this clinic
    const clinicUsers = await db
      .select({id: users.id})
      .from(users)
      .where(eq(users.clinicId, clinicId));

    // Extract user IDs
    const userIds = clinicUsers.map(user => user.id);

    // Return empty result if no users found
    if (userIds.length === 0) {
      return { logs: [], total: 0 };
    }

    // Get total count for this clinic - use inArray instead of raw SQL
    const [countResult] = await db
      .select({
        count: count()
      })
      .from(auditLogs)
      .where(inArray(auditLogs.userId, userIds));

    // Get logs for this clinic with pagination - use inArray instead of raw SQL
    const logs = await db
      .select({
        ...auditLogs,
        username: users.username
      })
      .from(auditLogs)
      .leftJoin(users, eq(auditLogs.userId, users.id))
      .where(inArray(auditLogs.userId, userIds))
      .limit(limit)
      .offset(offset)
      .orderBy(desc(auditLogs.timestamp));

    return {
      logs,
      total: countResult.count
    };
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  async getUserCount(): Promise<number> {
    const result = await db.select({ count: count() }).from(users);
    return result[0].count;
  }

  async getClinicUserCount(clinicId: string): Promise<number> {
    const result = await db
      .select({ count: count() })
      .from(users)
      .where(eq(users.clinicId, clinicId));
    return result[0].count;
  }

  async getDoctorsByClinic(clinicId: string): Promise<User[]> {
    try {
      console.log(`Fetching doctors for clinic ${clinicId}...`);

      // Get users with role='doctor' from the specified clinic
      const doctors = await db
        .select()
        .from(users)
        .where(
          and(
            eq(users.clinicId, clinicId),
            eq(users.role, 'doctor')
          )
        );

      console.log(`Found ${doctors.length} doctors for clinic ${clinicId}`);
      return doctors;
    } catch (error) {
      console.error(`Error fetching doctors for clinic ${clinicId}:`, error);
      return [];
    }
  }

  async updateUserRole(userId: number, role: string): Promise<boolean> {
    const result = await db.update(users)
      .set({ role })
      .where(eq(users.id, userId))
      .returning();

    return result.length > 0;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Patient methods
  async getPatient(id: number): Promise<Patient | undefined> {
    const [patient] = await db
      .select()
      .from(patients)
      .where(eq(patients.id, id));
    return patient;
  }

  async getPatientByPatientId(patientId: string): Promise<Patient | undefined> {
    const [patient] = await db
      .select()
      .from(patients)
      .where(eq(patients.patientId, patientId));
    return patient;
  }

  async getAllPatients(): Promise<Patient[]> {
    try {
      console.log('Fetching all patients from database...');
      const result = await db.select().from(patients);
      console.log(`Successfully fetched ${result.length} patients`);
      return result;
    } catch (error) {
      console.error('Error in getAllPatients:', error);
      throw error;
    }
  }

  async getPatientsByClinic(clinicId: string): Promise<Patient[]> {
    try {
      console.log(`Fetching patients for clinic ${clinicId}...`);

      // Get patients that either belong to this clinic OR have no clinic 
      // (legacy records before clinic_id was implemented)
      const result = await db
        .select()
        .from(patients)
        .where(
          or(
            eq(patients.clinicId, clinicId),
            isNull(patients.clinicId)
          )
        );

      console.log(`Successfully fetched ${result.length} patients for clinic ${clinicId}`);
      return result;
    } catch (error) {
      console.error(`Error getting patients for clinic ${clinicId}:`, error);
      throw error;
    }
  }

  async getPatientCount(): Promise<number> {
    const result = await db.select({ count: count() }).from(patients);
    return result[0].count;
  }

  async getClinicPatientCount(clinicId: string): Promise<number> {
    try {
      // Count patients that belong to this clinic OR have no clinic
      const result = await db
        .select({ count: count() })
        .from(patients)
        .where(
          or(
            eq(patients.clinicId, clinicId),
            isNull(patients.clinicId)
          )
        );

      return result[0].count;
    } catch (error) {
      console.error("Error counting clinic patients:", error);
      return 0; // Return 0 to avoid breaking the UI
    }
  }

  async createPatient(insertPatient: InsertPatient): Promise<Patient> {
    const [patient] = await db
      .insert(patients)
      .values(insertPatient)
      .returning();
    return patient;
  }

  async updatePatient(id: number, updatePatient: InsertPatient): Promise<Patient> {
    const [updatedPatient] = await db
      .update(patients)
      .set(updatePatient)
      .where(eq(patients.id, id))
      .returning();
    return updatedPatient;
  }

  async updatePatientStatus(id: number, status: string, inactiveReason?: string): Promise<Patient> {
    const updateData: Partial<Patient> = { status };

    // Only include inactive reason if provided and status is 'inactive'
    if (status === 'inactive' && inactiveReason) {
      updateData.inactiveReason = inactiveReason;
    } else if (status === 'active') {
      // Clear inactive reason when patient is marked as active
      updateData.inactiveReason = null;
    }

    const [updatedPatient] = await db
      .update(patients)
      .set(updateData)
      .where(eq(patients.id, id))
      .returning();

    return updatedPatient;
  }

  async searchPatients(query: string, clinicId?: string): Promise<Patient[]> {
    if (!query) return this.getAllPatients();

    const searchPattern = `%${query}%`;
    const baseQuery = db
      .select()
      .from(patients)
      .where(
        or(
          ilike(patients.firstName, searchPattern),
          ilike(patients.lastName, searchPattern),
          ilike(patients.patientId, searchPattern)
        )
      );

    // If clinicId is provided, add filter for that clinic
    if (clinicId) {
      return await baseQuery.where(eq(patients.clinicId, clinicId));
    }

    // Otherwise return all matching patients
    return await baseQuery;
  }

  async lookupPatients(query: string, clinicId?: string): Promise<Patient[]> {
    if (!query || query.length < 3) return [];

    const searchPattern = `%${query}%`;
    const baseQuery = db
      .select()
      .from(patients)
      .where(
        or(
          ilike(patients.firstName, searchPattern),
          ilike(patients.lastName, searchPattern),
          ilike(patients.patientId, searchPattern),
          ilike(patients.phone, searchPattern)
        )
      )
      .limit(10); // Limit results for better performance

    // If clinicId is provided, add filter for that clinic
    if (clinicId) {
      return await baseQuery.where(eq(patients.clinicId, clinicId));
    }

    // Otherwise return all matching patients
    return await baseQuery;
  }

  // Medical record methods
  async getMedicalRecord(id: number): Promise<MedicalRecord | undefined> {
    const [record] = await db
      .select()
      .from(medicalRecords)
      .where(eq(medicalRecords.id, id));
    return record;
  }

  async getAllMedicalRecords(): Promise<MedicalRecord[]> {
    return await db.select().from(medicalRecords);
  }

  async getMedicalRecordCount(): Promise<number> {
    const result = await db.select({ count: count() }).from(medicalRecords);
    return result[0].count;
  }

  async getClinicMedicalRecordCount(clinicId: string): Promise<number> {
    try {
      // First get the list of users who belong to this clinic
      const clinicUsers = await db
        .select({id: users.id})
        .from(users)
        .where(eq(users.clinicId, clinicId));

      // Extract user IDs
      const userIds = clinicUsers.map(user => user.id);

      // Return 0 if no users found
      if (userIds.length === 0) {
        return 0;
      }

      // Count medical records associated with patients in this clinic directly
      // Join through doctor since patients don't have clinicId directly
      const result = await db
        .select({ count: count() })
        .from(medicalRecords)
        .innerJoin(users, eq(medicalRecords.doctorId, users.id))
        .where(eq(users.clinicId, clinicId));

      return result[0].count;
    } catch (error) {
      console.error("Error counting clinic medical records:", error);
      return 0; // Return 0 to avoid breaking the UI
    }
  }

  async getPatientMedicalRecords(patientId: number): Promise<MedicalRecord[]> {
    return await db
      .select()
      .from(medicalRecords)
      .where(eq(medicalRecords.patientId, patientId));
  }

  async createMedicalRecord(insertRecord: InsertMedicalRecord): Promise<MedicalRecord> {
    const [record] = await db
      .insert(medicalRecords)
      .values(insertRecord)
      .returning();
    return record;
  }

  async updateMedicalRecord(id: number, updateData: Partial<InsertMedicalRecord>): Promise<MedicalRecord> {
    try {
      console.log(`Updating medical record with ID ${id}`, updateData);
      const [updatedRecord] = await db
        .update(medicalRecords)
        .set(updateData)
        .where(eq(medicalRecords.id, id))
        .returning();

      if (!updatedRecord) {
        throw new Error(`Medical record with ID ${id} not found`);
      }

      console.log(`Successfully updated medical record with ID ${id}`);
      return updatedRecord;
    } catch (error) {
      console.error(`Error updating medical record with ID ${id}:`, error);
      throw error;
    }
  }

  // Appointment methods
  async getAppointment(id: number): Promise<Appointment | undefined> {
    const [appointment] = await db
      .select()
      .from(appointments)
      .where(eq(appointments.id, id));
    return appointment;
  }

  async getAllAppointments(): Promise<Appointment[]> {
    return await db.select().from(appointments);
  }

  async getAppointmentsByClinic(clinicId: string): Promise<Appointment[]> {
    try {
      console.log(`Fetching appointments for clinic ${clinicId}...`);

      // Get only doctors from the clinic
      const clinicDoctors = await db
        .select({id: users.id})
        .from(users)
        .where(and(
          eq(users.clinicId, clinicId),
          eq(users.role, 'doctor')
        ));

      // Extract doctor IDs
      const doctorIds = clinicDoctors.map(doctor => doctor.id);

      // Return empty array if no users found
      if (doctorIds.length === 0) {
        console.log(`No doctors found for clinic ${clinicId}`);
        return [];
      }

      // Find appointments associated with clinic's doctors
      const result = await db
        .select()
        .from(appointments)
        .where(inArray(appointments.doctorId, doctorIds));

      console.log(`Successfully fetched ${result.length} appointments for clinic ${clinicId}`);
      return result;
    } catch (error) {
      console.error(`Error getting appointments for clinic ${clinicId}:`, error);
      throw error;
    }
  }

  async getAppointmentCount(): Promise<number> {
    const result = await db.select({ count: count() }).from(appointments);
    return result[0].count;
  }

  async getClinicAppointmentCount(clinicId: string): Promise<number> {
    try {
      // First get the list of users who belong to this clinic
      const clinicUsers = await db
        .select({id: users.id})
        .from(users)
        .where(eq(users.clinicId, clinicId));

      // Extract user IDs
      const userIds = clinicUsers.map(user => user.id);

      // Return 0 if no users found
      if (userIds.length === 0) {
        return 0;
      }

      // Count appointments associated with doctors from this clinic
      const result = await db
        .select({ count: count() })
        .from(appointments)
        .innerJoin(users, eq(appointments.doctorId, users.id))
        .where(eq(users.clinicId, clinicId));

      return result[0].count;
    } catch (error) {
      console.error("Error counting clinic appointments:", error);
      return 0; // Return 0 to avoid breaking the UI
    }
  }

  async getPatientAppointments(patientId: number): Promise<Appointment[]> {
    return await db
      .select()
      .from(appointments)
      .where(eq(appointments.patientId, patientId));
  }

  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const [appointment] = await db
      .insert(appointments)
      .values(insertAppointment)
      .returning();
    return appointment;
  }

  async updateAppointment(id: number, updateData: Partial<InsertAppointment>): Promise<Appointment> {
    const [updatedAppointment] = await db
      .update(appointments)
      .set(updateData)
      .where(eq(appointments.id, id))
      .returning();
    return updatedAppointment;
  }

  // Fuzzy search for patients
  async fuzzySearchPatients(query: string, clinicId?: string): Promise<Patient[]> {
    if (!query || query.length < 3) return [];

    // Get all patients
    const allPatients = await this.getAllPatients();

    // If clinicId is provided, filter patients first
    const patientsToSearch = clinicId 
      ? allPatients.filter(patient => patient.clinicId === clinicId)
      : allPatients;

    const fuse = new Fuse(patientsToSearch, {
      keys: [
        { name: 'firstName', weight: 0.3 },
        { name: 'lastName', weight: 0.3 },
        { name: 'patientId', weight: 0.6 },
        { name: 'phone', weight: 0.2 },
        { name: 'email', weight: 0.2 },
      ],
      includeScore: true,
      threshold: 0.4, // Lower means more strict matching
      minMatchCharLength: 2,
      // Allow fuzzy matching to find partial matches
      shouldSort: true
    });

    const results = fuse.search(query);
    return results.map(result => result.item);
  }

  // Find potential duplicate patients
  async findPotentialDuplicates(patient: InsertPatient | Patient): Promise<PotentialDuplicate[]> {
    const allPatients = await this.getAllPatients();
    const potentialDuplicates: PotentialDuplicate[] = [];

    // If this is an existing patient, remove it from the list to check
    const patientsToCheck = 'id' in patient 
      ? allPatients.filter(p => p.id !== (patient as Patient).id)
      : allPatients;

    for (const existingPatient of patientsToCheck) {
      const matchedOn: string[] = [];
      let score = 0;

      // Check the four key fields required for duplicate detection
      // 1. First name
      if (patient.firstName && existingPatient.firstName && 
          patient.firstName.toLowerCase() === existingPatient.firstName.toLowerCase()) {
        matchedOn.push('firstName');
        score += 0.25;
      }

      // 2. Last name
      if (patient.lastName && existingPatient.lastName && 
          patient.lastName.toLowerCase() === existingPatient.lastName.toLowerCase()) {
        matchedOn.push('lastName');
        score += 0.25;
      }

      // 3. Date of birth
      if (patient.dateOfBirth && existingPatient.dateOfBirth && 
          patient.dateOfBirth === existingPatient.dateOfBirth) {
        matchedOn.push('dateOfBirth');
        score += 0.25;
      }

      // 4. Birth certificate number
      if (patient.birthCertificateNumber && existingPatient.birthCertificateNumber && 
          patient.birthCertificateNumber === existingPatient.birthCertificateNumber) {
        matchedOn.push('birthCertificateNumber');
        score += 0.25;
      }

      // Check if we have a perfect match on all four fields
      const isExactMatch = matchedOn.includes('firstName') && 
                           matchedOn.includes('lastName') && 
                           matchedOn.includes('dateOfBirth') && 
                           matchedOn.includes('birthCertificateNumber');

      // Check if we have a match on three fields but not birth certificate
      const isPartialMatch = matchedOn.includes('firstName') && 
                             matchedOn.includes('lastName') && 
                             matchedOn.includes('dateOfBirth') && 
                             !matchedOn.includes('birthCertificateNumber');

      // Per requirements: Only flag as duplicate if ALL four match exactly
      // Or show a warning if three match but birth certificate differs
      if (isExactMatch || isPartialMatch) {
        potentialDuplicates.push({
          patient: existingPatient,
          score: isExactMatch ? 1.0 : 0.75, // Perfect match or partial match
          matchedOn
        });
      }
    }

    // Sort by score descending
    return potentialDuplicates.sort((a, b) => b.score - a.score);
  }

  // Merge two patient records
  async mergePatients(sourceId: number, targetId: number): Promise<Patient> {
    // Get the source patient (will be merged into target)
    const sourcePatient = await this.getPatient(sourceId);
    // Get the target patient (will receive data from source)
    const targetPatient = await this.getPatient(targetId);

    if (!sourcePatient || !targetPatient) {
      throw new Error('Both source and target patients must exist');
    }

    // Start a transaction since we're updating multiple related records
    return await db.transaction(async (tx) => {
      // Update all medical records from source to point to target
      await tx
        .update(medicalRecords)
        .set({ patientId: targetId })
        .where(eq(medicalRecords.patientId, sourceId));

      // Update all appointments from source to point to target
      await tx
        .update(appointments)
        .set({ patientId: targetId })
        .where(eq(appointments.patientId, sourceId));

      // Update all patient results from source to point to target
      await tx
        .update(patientResults)
        .set({ patientId: targetId })
        .where(eq(patientResults.patientId, sourceId));

      // Optional: Create a merged patient record with most complete data
      const mergedData: Partial<Patient> = {};

      // For each field, prefer target data unless it's empty
      Object.keys(targetPatient).forEach(key => {
        const field = key as keyof Patient;
        if (field !== 'id' && field !== 'patientId') {
          // Use source data only if target data is empty/null and source has data
          if (!targetPatient[field] && sourcePatient[field]) {
            mergedData[field] = sourcePatient[field];
          }
        }
      });

      // Update the target patient with any missing data from source
      if (Object.keys(mergedData).length > 0) {
        const [updatedPatient] = await tx
          .update(patients)
          .set(mergedData as any)
          .where(eq(patients.id, targetId))
          .returning();

        // Delete the source patient
        await tx
          .delete(patients)
          .where(eq(patients.id, sourceId));

        return updatedPatient;
      } else {
        // Delete the source patient
        await tx
          .delete(patients)
          .where(eq(patients.id, sourceId));

        return targetPatient;
      }
    });
  }

  // Patient result methods
  async getPatientResult(id: number): Promise<PatientResult | undefined> {
    const [result] = await db
      .select()
      .from(patientResults)
      .where(eq(patientResults.id, id));
    return result;
  }

  async getAllPatientResults(): Promise<PatientResult[]> {
    return await db
      .select()
      .from(patientResults)
      .orderBy(patientResults.testDate, 'desc');
  }

  async getPatientResults(patientId: number): Promise<PatientResult[]> {
    return await db
      .select()
      .from(patientResults)
      .where(eq(patientResults.patientId, patientId))
      .orderBy(patientResults.testDate, 'desc');
  }

  async createPatientResult(insertResult: InsertPatientResult): Promise<PatientResult> {
    const[result] = await db      .insert(patientResults)
      .values(insertResult)
      .returning();
    return result;
  }

  async updatePatientResult(id: number, updateData: Partial<InsertPatientResult>): Promise<PatientResult> {
    const [updatedResult] = await db
      .update(patientResults)
      .set(updateData)
      .where(eq(patientResults.id, id))
      .returning();
    return updatedResult;
  }

  async deletePatientResult(id: number): Promise<void> {
    await db
      .delete(patientResults)
      .where(eq(patientResults.id, id));
  }

  // Clinic methods
  async getClinic(id: string): Promise<Clinic | undefined> {
    const [clinic] = await db
      .select()
      .from(clinics)
      .where(eq(clinics.id, id));
    return clinic;
  }

  async getAllClinics(): Promise<(Clinic & { adminName?: string, adminRole?: string })[]> {
    try {
      console.log('Fetching all clinics from database...');
      // Get clinics
      const clinicsList = await db
        .select()
        .from(clinics);

      console.log(`Successfully fetched ${clinicsList.length} clinics`);

      // For each clinic, find the admin user (super_admin role)
      const resultWithAdmins = await Promise.all(
        clinicsList.map(async (clinic) => {
          // Find admin users for this clinic
          const adminUsers = await db
            .select({
              id: users.id,
              username: users.username,
              fullName: users.fullName,
              role: users.role
            })
            .from(users)
            .where(sql`${users.clinicId} = ${clinic.id} AND ${users.role} = 'super_admin'`);

          const adminUser = adminUsers[0]; // Get the first admin (should be only one)

          // Add admin info to the clinic object
          return {
            ...clinic,
            adminName: adminUser?.fullName || adminUser?.username || null,
            adminRole: adminUser?.role || null
          };
        })
      );

      return resultWithAdmins;
    } catch (error) {
      console.error('Error in getAllClinics:', error);
      throw error;
    }
  }

  async createClinic(insertClinic: InsertClinic): Promise<Clinic> {
    const [clinic] = await db
      .insert(clinics)
      .values(insertClinic)
      .returning();
    return clinic;
  }

  // Invoice methods
  async createInvoice(insertInvoice: InsertInvoice): Promise<Invoice> {
    const [invoice] = await db
      .insert(invoices)
      .values(insertInvoice)
      .returning();
    return invoice;
  }

  async getInvoice(id: number): Promise<Invoice | undefined> {
    const [invoice] = await db
      .select()
      .from(invoices)
      .where(eq(invoices.id, id));
    return invoice;
  }

  async getInvoicesByClinic(clinicId: string): Promise<Invoice[]> {
    return db
      .select()
      .from(invoices)
      .where(eq(invoices.clinicId, clinicId))
      .orderBy(invoices.createdAt, 'desc');
  }

  async getAllInvoices(options?: {page: number, limit: number}): Promise<{invoices: Invoice[], total: number}> {
    const page = options?.page || 1;
    const limit = options?.limit || 50;
    const offset = (page - 1) * limit;

    // Get total count
    const [countResult] = await db
      .select({
        count: count()
      })
      .from(invoices);

    // Get invoices with pagination
    const invoicesList = await db
      .select()
      .from(invoices)
      .limit(limit)
      .offset(offset)
      .orderBy(invoices.createdAt, 'desc');

    return {
      invoices: invoicesList,
      total: countResult.count
    };
  }

  async updateInvoice(id: number, updateData: Partial<InsertInvoice>): Promise<Invoice> {
    const [updatedInvoice] = await db
      .update(invoices)
      .set(updateData)
      .where(eq(invoices.id, id))
      .returning();
    return updatedInvoice;
  }

  // Subscription methods
  async getSubscription(id: number): Promise<Subscription | undefined> {
    const [subscription] = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.id, id));
    return subscription;
  }

  async getSubscriptionByClinic(clinicId: string): Promise<Subscription | undefined> {
    const [subscription] = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.clinicId, clinicId))
      .orderBy(subscriptions.createdAt, 'desc'); // Get the most recent subscription
    return subscription;
  }

  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    const [subscription] = await db
      .insert(subscriptions)
      .values(insertSubscription)
      .returning();
    return subscription;
  }

  async updateSubscription(id: number, updateData: Partial<InsertSubscription>): Promise<Subscription> {
    const [updatedSubscription] = await db
      .update(subscriptions)
      .set(updateData)
      .where(eq(subscriptions.id, id))
      .returning();
    return updatedSubscription;
  }

  async updateSubscriptionStripeInfo(id: number, stripeInfo: { stripeCustomerId: string, stripeSubscriptionId: string }): Promise<Subscription> {
    const [updatedSubscription] = await db
      .update(subscriptions)
      .set({
        stripeCustomerId: stripeInfo.stripeCustomerId,
        stripeSubscriptionId: stripeInfo.stripeSubscriptionId,
        status: 'active', // Update status to active once Stripe subscription is created
        updatedAt: new Date()
      })
      .where(eq(subscriptions.id, id))
      .returning();
    return updatedSubscription;
  }
}

export const storage = new DatabaseStorage();