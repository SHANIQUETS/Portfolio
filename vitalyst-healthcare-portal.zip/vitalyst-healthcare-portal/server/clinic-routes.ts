import type { Express, Request, Response, NextFunction } from "express";
import { storage } from "./storage";
import { createAuditLog } from "./audit";
// Import from ES module
import * as clinicManagement from './clinic-management.js';
import { pool } from "./db";
import { requireSystemAdmin, requireClinicSuperAdmin, requireAdminOrSuperAdmin } from "./middleware/admin-middleware";
import { createClinicCheckoutSession } from "./clinic-checkout";

// Import constants for pricing
import { STRIPE_AMOUNT_IDS, CLINIC_TIER_PRICING } from "../client/src/lib/constants";

/**
 * Register clinic management routes
 */
export function registerClinicRoutes(app: Express) {
  // Get clinic tier information
  // Create checkout session for clinic subscription
  app.post("/api/clinic/checkout", requireClinicSuperAdmin, createClinicCheckoutSession);

  app.get("/api/clinic/tiers", (req, res) => {
    // This doesn't need authentication as it's public information for the signup page
    const tiers = {
      sole_trader: { 
        name: "Sole Trader", 
        description: "Perfect for individual practitioners",
        limits: { doctor: 1, nurse: 1, clerk: 1, super_admin: 1 },
        price: "$100/month"
      },
      small_clinic: { 
        name: "Small Clinic", 
        description: "Great for small medical practices",
        limits: { doctor: 2, nurse: 2, clerk: 2, super_admin: 1 },
        price: "$150/month"
      },
      standard_clinic: { 
        name: "Standard Clinic", 
        description: "For established medical practices",
        limits: { doctor: 3, nurse: 4, clerk: 3, super_admin: 1 },
        price: "$200/month"
      },
      enterprise: { 
        name: "Enterprise", 
        description: "Unlimited users for large hospitals",
        limits: { doctor: "Unlimited", nurse: "Unlimited", clerk: "Unlimited", super_admin: 1 },
        price: "Custom pricing",
        isCustom: true
      }
    };

    res.json(tiers);
  });

  // Get current clinic information (for authenticated users)
  app.get("/api/clinic", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      // Get clinic information from database based on the user's clinic_id
      const clinicResult = await pool.query(
        'SELECT * FROM clinics WHERE id = (SELECT clinic_id FROM users WHERE id = $1)',
        [req.user.id]
      );

      if (!clinicResult.rows.length) {
        return res.status(404).json({ message: "Clinic not found" });
      }

      const clinic = clinicResult.rows[0];

      // Get user counts by role
      const userCountsResult = await pool.query(
        'SELECT role, COUNT(*) FROM users WHERE clinic_id = $1 GROUP BY role',
        [clinic.id]
      );

      const userCounts: Record<string, number> = {};
      userCountsResult.rows.forEach((row: any) => {
        userCounts[row.role] = parseInt(row.count);
      });

      // Return clinic data with usage information
      res.json({
        ...clinic,
        userCounts,
        // Calculate remaining available slots
        available: Object.keys(clinic.user_limits).reduce((acc: Record<string, string|number>, role) => {
          const limit = clinic.user_limits[role];
          const count = userCounts[role] || 0;
          acc[role] = limit === Infinity ? "Unlimited" : Math.max(0, limit - count);
          return acc;
        }, {} as Record<string, string|number>)
      });
    } catch (error) {
      console.error("Error fetching clinic information:", error);
      res.status(500).json({ message: "Error fetching clinic information" });
    }
  });

  // Create a new clinic (registration endpoint)
  app.post("/api/clinic/register", async (req, res) => {
    try {
      const { name, tier, superAdminName, superAdminEmail, password, entityType } = req.body;

      if (!name || !tier || !superAdminName || !superAdminEmail || !password) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      // Validate password (minimum 8 characters, at least one number and one special character)
      const passwordRegex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$/;
      if (!passwordRegex.test(password)) {
        return res.status(400).json({ 
          message: "Password must be at least 8 characters long and include at least one number and one special character"
        });
      }

      // Check if email is already in use
      const existingUser = await storage.getUserByUsername(superAdminEmail);
      if (existingUser) {
        return res.status(400).json({ message: "Email already in use" });
      }

      // Create the clinic and super admin user
      const clinic = await clinicManagement.onboardClinic(pool, {
        name,
        tier,
        superAdminName,
        superAdminEmail,
        password,
        // Always force "clinic" for self-registrations
        // Only system admins can create platform_admin entities through admin-routes.ts
        entityType: "clinic"  
      });

      res.status(201).json({ 
        message: "Clinic registered successfully", 
        clinic: { id: clinic.id, name: clinic.name, tier: clinic.tier } 
      });
    } catch (error) {
      console.error("Error registering clinic:", error);
      res.status(500).json({ message: `Error registering clinic: ${error.message}` });
    }
  });

  // Update clinic tier (requires clinic super admin)
  app.post("/api/clinic/upgrade", requireClinicSuperAdmin, async (req, res) => {
    try {
      const { tier } = req.body;

      if (!tier) {
        return res.status(400).json({ message: "Tier is required" });
      }

      // Get the user's clinic
      const clinicResult = await pool.query(
        'SELECT * FROM clinics WHERE id = (SELECT clinic_id FROM users WHERE id = $1)',
        [req.user.id]
      );

      if (!clinicResult.rows.length) {
        return res.status(404).json({ message: "Clinic not found" });
      }

      const clinic = clinicResult.rows[0];

      // Update the clinic tier
      // IMPORTANT: We don't update entity_type here to ensure it cannot be changed
      // through the clinic's own routes - only admins should be able to change entity_type
      const updatedClinic = await pool.query(
        'UPDATE clinics SET tier = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
        [tier, clinic.id]
      );

      // Create audit log
      await createAuditLog(
        req,
        "update",
        "clinic",
        clinic.id,
        `Updated clinic tier from ${clinic.tier} to ${tier}`
      );

      res.json({
        message: "Clinic tier updated successfully",
        clinic: updatedClinic.rows[0]
      });
    } catch (error) {
      console.error("Error updating clinic tier:", error);
      res.status(500).json({ message: `Error updating clinic tier: ${error.message}` });
    }
  });

  // Create a new user for this clinic (requires admin/super_admin)
  app.post("/api/clinic/users", requireAdminOrSuperAdmin, async (req, res) => {

    try {
      // Verify user can create other users
      const canCreate = await clinicManagement.checkUserPermission(pool, req.user.id, "manage_users").catch(() => false);
      if (!canCreate) {
        return res.status(403).json({ message: "Forbidden: You don't have permission to create users" });
      }

      const { name, email, username, password, role } = req.body;

      if (!name || !email || !username || !password || !role) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      // Validate password (minimum 8 characters, at least one number and one special character)
      const passwordRegex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$/;
      if (!passwordRegex.test(password)) {
        return res.status(400).json({ 
          message: "Password must be at least 8 characters long and include at least one number and one special character"
        });
      }

      // Log user information for debugging
      console.log('Creating user with authenticated user:', JSON.stringify({
        id: req.user.id,
        role: req.user.role,
        clinic_id: req.user.clinic_id,
        clinicId: req.user.clinicId
      }));

      // Create the user
      const newUser = await clinicManagement.createUser(pool, req.user, {
        name,
        email,
        username,
        password,
        role
      });

      // Create audit log
      await storage.createAuditLog({
        userId: req.user.id,
        action: "create",
        entityType: "user",
        entityId: newUser.id,
        details: `Created new user ${newUser.username} with role ${newUser.role}`,
        ipAddress: req.ip,
        timestamp: new Date(),
        clinicId: req.user.clinicId
      });

      // Remove password from response
      const { password: _, ...userResponse } = newUser;

      res.status(201).json({
        message: "User created successfully",
        user: userResponse
      });
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: `Error creating user: ${error.message}` });
    }
  });

  // Grant temporary support access (requires clinic super admin)
  app.post("/api/clinic/support-access", requireClinicSuperAdmin, async (req, res) => {
    try {
      const { supportUserId } = req.body;

      if (!supportUserId) {
        return res.status(400).json({ message: "Support user ID is required" });
      }

      // Get the user's clinic
      const clinicResult = await pool.query(
        'SELECT * FROM clinics WHERE id = (SELECT clinic_id FROM users WHERE id = $1)',
        [req.user.id]
      );

      if (!clinicResult.rows.length) {
        return res.status(404).json({ message: "Clinic not found" });
      }

      const clinic = clinicResult.rows[0];

      // Grant support access
      const access = await clinicManagement.grantSupportAccess(pool, req.user.id, supportUserId, clinic.id);

      // Create audit log
      await createAuditLog(
        req,
        "create",
        "support_access",
        access.id,
        `Granted temporary support access to user ${supportUserId}`
      );

      res.status(201).json({
        message: "Support access granted successfully",
        access
      });
    } catch (error) {
      console.error("Error granting support access:", error);
      res.status(500).json({ message: `Error granting support access: ${error.message}` });
    }
  });

  // Check support access (for support staff)
  app.get("/api/clinic/:clinicId/support-access", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const { clinicId } = req.params;

      if (!clinicId) {
        return res.status(400).json({ message: "Clinic ID is required" });
      }

      // Check if the user has support access to this clinic
      const hasAccess = await clinicManagement.checkSupportAccess(pool, req.user.id, clinicId).catch(() => false);

      if (!hasAccess) {
        return res.status(403).json({ message: "No active support access for this clinic" });
      }

      res.json({
        message: "Support access confirmed",
        status: "active"
      });
    } catch (error) {
      console.error("Error checking support access:", error);
      res.status(500).json({ message: `Error checking support access: ${error.message}` });
    }
  });

  // List users in the clinic - only accessible to clinic super admins
  app.get("/api/clinic/users", requireClinicSuperAdmin, async (req, res) => {

    try {
      // Get the user's clinic ID
      const clinicResult = await pool.query(
        'SELECT clinic_id FROM users WHERE id = $1',
        [req.user.id]
      );

      if (!clinicResult.rows.length || !clinicResult.rows[0].clinic_id) {
        return res.status(404).json({ message: "Clinic not found" });
      }

      const clinicId = clinicResult.rows[0].clinic_id;

      // Get all users in this clinic
      const users = await pool.query(
        'SELECT id, username, full_name as "fullName", role, email, specialization, is_primary as "isPrimary" FROM users WHERE clinic_id = $1',
        [clinicId]
      );

      res.json(users.rows);
    } catch (error) {
      console.error("Error fetching clinic users:", error);
      res.status(500).json({ message: "Error fetching clinic users" });
    }
  });

  // Create a new subscription for a clinic
  app.post("/api/clinic/subscription", requireClinicSuperAdmin, async (req, res) => {
    try {
      const { tier, paymentMethodId } = req.body;

      if (!tier) {
        return res.status(400).json({ message: "Tier is required" });
      }

      // Get the user's clinic
      const clinicResult = await pool.query(
        'SELECT * FROM clinics WHERE id = (SELECT clinic_id FROM users WHERE id = $1)',
        [req.user.id]
      );

      if (!clinicResult.rows.length) {
        return res.status(404).json({ message: "Clinic not found" });
      }

      const clinic = clinicResult.rows[0];
      const clinicId = clinic.id;

      // Check if subscription tier is valid
      if (!STRIPE_AMOUNT_IDS[tier] && tier !== 'enterprise') {
        return res.status(400).json({ message: "Invalid subscription tier" });
      }

      // Calculate the amount based on the tier
      let amount;
      let isCustomPricing = false;

      if (tier === 'enterprise') {
        amount = req.body.amount; // Enterprise has custom pricing
        isCustomPricing = true;

        if (!amount) {
          return res.status(400).json({ message: "Amount is required for enterprise tier" });
        }
      } else {
        amount = CLINIC_TIER_PRICING[tier];
      }

      // MOCK STRIPE IMPLEMENTATION
      // In a real implementation, this is where we would call Stripe APIs

      // Mock a stripe customer ID
      const mockStripeCustomerId = `cus_mock_${Date.now()}`;

      // Mock a stripe subscription ID
      const mockStripeSubscriptionId = `sub_mock_${Date.now()}`;

      // Create a new subscription record in our database
      const subscriptionData = {
        clinicId,
        tier,
        amount,
        isCustomPricing,
        startDate: new Date(),
        status: 'active',
        stripeCustomerId: mockStripeCustomerId,
        stripeSubscriptionId: mockStripeSubscriptionId
      };

      const subscription = await storage.createSubscription(subscriptionData);

      // Update the clinic's tier
      await pool.query(
        'UPDATE clinics SET tier = $1, updated_at = NOW() WHERE id = $2',
        [tier, clinicId]
      );

      // Create audit log
      await createAuditLog(
        req,
        "create",
        "subscription",
        subscription.id,
        `Created new ${tier} subscription for clinic ${clinicId}`
      );

      res.status(201).json({
        message: "Subscription created successfully",
        subscription
      });
    } catch (error) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ message: `Error creating subscription: ${error.message}` });
    }
  });

  // Get clinic billing data - restricted to super admins with clinic scope
  app.get("/api/clinic/billing", requireClinicSuperAdmin, async (req, res) => {
    if (!req.user || !req.user.clinic_id) {
      return res.status(403).json({ 
        error: "Forbidden",
        message: "No clinic association found" 
      });
    }

    try {
      // Get billing data for the super admin's clinic only
      const result = await pool.query(`
        SELECT b.*, s.status as subscription_status, s.tier
        FROM billing b
        LEFT JOIN subscriptions s ON b.subscription_id = s.id
        WHERE b.clinic_id = $1
        ORDER BY b.created_at DESC
      `, [req.user.clinic_id]);

      res.json(result.rows);
    } catch (error) {
      console.error("Error fetching clinic billing data:", error);
      res.status(500).json({ message: "Error fetching billing data" });
    }
  });

  // Get clinic billing data - restricted to super admins with clinic scope
  app.get("/api/clinic/billing", requireClinicSuperAdmin, async (req, res) => {
    if (!req.user || !req.user.clinic_id) {
      return res.status(403).json({ 
        error: "Forbidden",
        message: "No clinic association found" 
      });
    }

    try {
      // Get billing data for the super admin's clinic only
      const billingResult = await pool.query(`
        SELECT 
          b.*, 
          s.status AS subscription_status, 
          s.tier AS subscription_tier 
        FROM billing b
        LEFT JOIN subscriptions s ON b.subscription_id = s.id
        WHERE b.clinic_id = $1
        ORDER BY b.created_at DESC
      `, [req.user.clinic_id]);

      res.json(billingResult.rows);
    } catch (error) {
      console.error("Error fetching clinic billing data:", error);
      res.status(500).json({ message: "Error fetching billing data" });
    }
  });

  // Get active subscription for a clinic
  app.get("/api/clinic/subscription", requireClinicSuperAdmin, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Get the user's clinic ID
      const clinicResult = await pool.query(
        'SELECT clinic_id FROM users WHERE id = $1',
        [req.user.id]
      );

      if (!clinicResult.rows.length || !clinicResult.rows[0].clinic_id) {
        return res.status(404).json({ message: "Clinic not found" });
      }

      const clinicId = clinicResult.rows[0].clinic_id;

      // Get the active subscription for this clinic
      const subscription = await storage.getSubscriptionByClinic(clinicId);

      if (!subscription) {
        return res.status(404).json({ message: "No active subscription found" });
      }

      res.json(subscription);
    } catch (error) {
      console.error("Error fetching subscription:", error);
      res.status(500).json({ message: "Error fetching subscription" });
    }
  });
}