import { Router } from "express";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

export const authRouter = Router();

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  if (!stored || !stored.includes(".")) {
    return false;
  }

  try {
    const [hashed, salt] = stored.split(".");
    const hashedBuf = Buffer.from(hashed, "hex");
    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    return timingSafeEqual(hashedBuf, suppliedBuf);
  } catch (error) {
    console.error("Password comparison error:", error);
    return false;
  }
}

export function setupAuth(app: Express.Application) {
  console.log("Setting up session middleware");

  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET as string,
    resave: true,
    saveUninitialized: false,
    store: storage.sessionStore,
    name: 'connect.sid',
    proxy: true,
    cookie: {
      secure: false,  // false during local dev (HTTP)
      httpOnly: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 24 * 60 * 60 * 1000
    }
  };

  console.log("Session store type:", typeof storage.sessionStore);

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        } else {
          return done(null, user);
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user: Express.User, done) => {
    console.log("Serializing user:", user.id);
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      console.log("Deserializing user ID:", id);
      const user = await storage.getUser(id);
      if (user) {
        console.log("User found during deserialization:", user.id, user.username);

        if (process.env.CLERK_SECRET_KEY && user.clinicId) {
          try {
            const clerk = require('@clerk/clerk-sdk-node');
            await clerk.users.updateUser(user.id.toString(), {
              unsafeMetadata: {
                clinicId: user.clinicId,
                isPrimary: user.isPrimary
              }
            });
          } catch (clerkError) {
            console.error("Error syncing with Clerk:", clerkError);
          }
        }

        done(null, user);
      } else {
        console.log("User not found during deserialization for ID:", id);
        done(new Error(`User not found for ID: ${id}`), null);
      }
    } catch (error) {
      console.error("Error during deserialization:", error);
      done(error, null);
    }
  });

  app.use('/api', authRouter);
}

authRouter.post("/register", async (req, res, next) => {
  try {
    const existingUser = await storage.getUserByUsername(req.body.username);
    if (existingUser) {
      return res.status(400).json({ message: "Username already exists" });
    }

    const user = await storage.createUser({
      ...req.body,
      password: await hashPassword(req.body.password),
    });

    req.login(user, (err) => {
      if (err) return next(err);
      res.status(201).json(user);
    });
  } catch (error) {
    next(error);
  }
});

// Development direct-login bypass removed from the public repository.

authRouter.post("/login", (req, res, next) => {
  console.log("Login attempt for:", req.body.username);
  passport.authenticate("local", (err, user, info) => {
    if (err) {
      console.error("Login error:", err);
      return res.status(500).json({ message: "Internal server error during login" });
    }

    if (!user) {
      console.log("Authentication failed - invalid credentials");
      return res.status(401).json({ message: "Invalid username or password" });
    }

    if (user.mustChangePassword) {
      return res.status(200).json({ 
        requirePasswordChange: true,
        userId: user.id,
        message: "Password change required"
      });
    }

    console.log("Authentication successful for user:", user.username, "ID:", user.id);

    req.login(user, (err) => {
      if (err) {
        console.error("Session error:", err);
        return res.status(500).json({ message: "Error creating session" });
      }

      console.log("Session created, ID:", req.sessionID, "User:", user.id);

      const safeUser = {
        id: user.id,
        username: user.username,
        role: user.role,
        clinicId: user.clinicId || null,
        fullName: user.fullName || user.username || "Unnamed User",
        email: user.email || `${user.username}@example.com`
      };

      return res.status(200).json(safeUser);
    });
  })(req, res, next);
});

authRouter.post("/logout", (req, res, next) => {
  req.logout((err) => {
    if (err) return next(err);
    res.sendStatus(200);
  });
});

authRouter.get("/user", async (req, res) => {
  console.log("GET /api/user - Session ID:", req.sessionID);
  console.log("Session data:", req.session);
  console.log("Is authenticated:", req.isAuthenticated());

  if (req.user) {
    console.log("User in session:", req.user.id, req.user.username);
    console.log("User authenticated via session, returning safe user data");
    return res.json({
      id: req.user.id,
      username: req.user.username,
      fullName: req.user.fullName || req.user.username || "Unnamed User",
      role: req.user.role,
      clinicId: req.user.clinicId || null,
      email: req.user.email || `${req.user.username}@example.com`,
      isPrimary: req.user.isPrimary ?? false
    });
  } else {
    console.log("No user in session");
  }

  console.log("User not authenticated, returning 401");
  return res.sendStatus(401);
});

authRouter.post("/register/system-admin", async (req, res, next) => {
  try {
    const { username, password, fullName, email, specialization } = req.body;

    if (!username || !password || !fullName) {
      return res.status(400).json({ 
        message: "Username, password, and full name are required" 
      });
    }

    const existingUser = await storage.getUserByUsername(username);
    if (existingUser) {
      return res.status(400).json({ message: "Username already exists" });
    }

    const user = await storage.createUser({
      username,
      password: await hashPassword(password),
      fullName,
      role: "super_admin",
      email: email || null,
      specialization: specialization || null
    });

    req.login(user, (err) => {
      if (err) return next(err);

      res.status(201).json({
        message: "System administrator account created successfully",
        user
      });
    });
  } catch (error) {
    console.error("Error creating system admin:", error);
    res.status(500).json({ 
      message: "Error creating system admin account",
      error: error instanceof Error ? error.message : String(error)
    });
  }
});

authRouter.post("/change-password", async (req, res) => {
  const { userId, currentPassword, newPassword } = req.body;

  try {
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const isValid = await comparePasswords(currentPassword, user.password);
    if (!isValid) {
      return res.status(401).json({ message: "Current password is incorrect" });
    }

    const hashedPassword = await hashPassword(newPassword);
    await storage.updateUser(userId, {
      password: hashedPassword,
      mustChangePassword: false
    });

    res.json({ message: "Password updated successfully" });
  } catch (error) {
    console.error("Error changing password:", error);
    res.status(500).json({ message: "Error updating password" });
  }
});