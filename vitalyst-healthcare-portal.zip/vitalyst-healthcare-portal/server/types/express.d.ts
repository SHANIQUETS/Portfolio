import { PlatformAdmin } from '@shared/schema';

declare global {
  namespace Express {
    interface Request {
      platformAdmin?: PlatformAdmin;
      clinicScope?: string;
    }
  }
}