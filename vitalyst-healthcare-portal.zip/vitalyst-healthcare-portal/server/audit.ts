import { storage } from "./storage";
import { InsertAuditLog } from "@shared/schema";
import { Request } from "express";

/**
 * Helper function to create audit logs for different operations
 * @param req Express request object (to get user info and IP)
 * @param action The action being performed (create, update, delete, view)
 * @param entityType The type of entity (patient, medical_record, appointment)
 * @param entityId The ID of the entity (optional)
 * @param details Additional details about the action
 * @returns The created audit log entry
 */
export async function createAuditLog(
  req: Request,
  action: string,
  entityType: string,
  entityId?: number,
  details?: string
) {
  if (!req.user) {
    console.warn("Attempted to create audit log without authenticated user");
    return null;
  }

  const auditLogData: InsertAuditLog = {
    userId: req.user.id,
    action,
    entityType,
    entityId,
    details: details || null,
    ipAddress: req.ip || null,
    clinicId: entityType === 'clinic' ? entityId : (req.user.clinicId || null)
  };

  // Enhanced debug logging
  console.log("📝 Creating audit log", {
    timestamp: new Date().toISOString(),
    method: req.method,
    path: req.originalUrl,
    action: auditLogData.action,
    entityType: auditLogData.entityType,
    entityId: auditLogData.entityId,
    userId: req.user.id,
    username: req.user.username,
    userRole: req.user.role,
    clinicId: auditLogData.clinicId,
    ipAddress: req.ip,
    details: auditLogData.details
  });

  try {
    return await storage.createAuditLog(auditLogData);
  } catch (error) {
    console.error("Error creating audit log:", error);
    return null;
  }
}

/**
 * Helper function to create audit logs specifically for entities with string IDs (like clinics)
 * This addresses the mismatch between string clinic IDs and integer entityIds in audit logs
 * 
 * @param req Express request object (to get user info and IP)
 * @param action The action being performed (create, update, delete, view)
 * @param entityType The type of entity (clinic, subscription)
 * @param stringId The string ID of the entity
 * @param details Additional details about the action
 * @returns The created audit log entry
 */
export async function createStringIdAuditLog(
  req: Request,
  action: string,
  entityType: string,
  stringId: string,
  details?: string
) {
  if (!req.user) {
    console.warn("Attempted to create audit log without authenticated user");
    return null;
  }

  // For entities with string IDs, we store the ID in the details field
  // and set entityId to null since it expects an integer
  const enhancedDetails = details 
    ? `${details} [ID: ${stringId}]`
    : `Operation on ${entityType} with ID: ${stringId}`;

  const auditLogData: InsertAuditLog = {
    userId: req.user.id,
    action,
    entityType,
    entityId: null, // We can't use string IDs in the entityId field
    details: enhancedDetails,
    ipAddress: req.ip || null
  };

  try {
    console.log(`Creating ${entityType} audit log with string ID: ${stringId}`);
    const result = await storage.createAuditLog(auditLogData);
    console.log("Audit log created successfully:", result?.id);
    return result;
  } catch (error) {
    console.error("Error creating audit log:", error);
    return null;
  }
}