/**
 * Migration script to add clinic management functionality
 * This includes clinic tiers, role limits, and support access tables
 */

import { pool } from './db';

async function runMigration() {
  const client = await pool.connect();
  try {
    // Start transaction
    await client.query('BEGIN');

    console.log("Starting clinic management migration...");

    // Create clinic tier enum type if it doesn't exist
    await client.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'clinic_tier') THEN
          CREATE TYPE clinic_tier AS ENUM ('sole_trader', 'small_clinic', 'standard_clinic', 'enterprise');
        END IF;
      END
      $$;
    `);

    // Create clinics table if it doesn't exist
    await client.query(`
      CREATE TABLE IF NOT EXISTS clinics (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        tier clinic_tier NOT NULL DEFAULT 'sole_trader',
        user_limits JSONB NOT NULL,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);

    // Add clinic_id to users table if it doesn't exist
    await client.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM information_schema.columns
          WHERE table_name = 'users' AND column_name = 'clinic_id'
        ) THEN
          ALTER TABLE users ADD COLUMN clinic_id TEXT REFERENCES clinics(id);
          ALTER TABLE users ADD COLUMN is_primary BOOLEAN DEFAULT FALSE;
        END IF;
      END
      $$;
    `);

    // Update the role field in users table to include super_admin
    await client.query(`
      DO $$
      BEGIN
        IF EXISTS (
          SELECT 1 FROM information_schema.columns 
          WHERE table_name = 'users' AND column_name = 'role'
        ) THEN
          -- Check if the comment exists to avoid duplicate modifications
          IF NOT EXISTS (
            SELECT 1 FROM pg_description 
            WHERE objoid = 'users'::regclass AND objsubid = (
              SELECT ordinal_position 
              FROM information_schema.columns 
              WHERE table_name = 'users' AND column_name = 'role'
            )::integer
            AND description LIKE '%super_admin%'
          ) THEN
            COMMENT ON COLUMN users.role IS 'Role can be: clerk, nurse, doctor, super_admin';
          END IF;
        END IF;
      END
      $$;
    `);

    // Create support_access table for temporary support access
    await client.query(`
      CREATE TABLE IF NOT EXISTS support_access (
        id SERIAL PRIMARY KEY,
        granted_by INTEGER NOT NULL REFERENCES users(id),
        support_user_id INTEGER NOT NULL REFERENCES users(id),
        clinic_id TEXT NOT NULL REFERENCES clinics(id),
        status TEXT NOT NULL DEFAULT 'active',
        granted_at TIMESTAMP DEFAULT NOW(),
        expires_at TIMESTAMP NOT NULL,
        UNIQUE(support_user_id, clinic_id)
      );
    `);

    // Insert default clinic if none exists
    const clinicCountResult = await client.query('SELECT COUNT(*) FROM clinics');
    if (parseInt(clinicCountResult.rows[0].count) === 0) {
      // Default clinic for existing data
      const defaultLimits = {
        doctor: 5,
        nurse: 5,
        clerk: 5,
        super_admin: 1
      };

      await client.query(`
        INSERT INTO clinics (id, name, tier, user_limits)
        VALUES ('clinic_default', 'Default Clinic', 'standard_clinic', $1)
      `, [JSON.stringify(defaultLimits)]);
      
      console.log("Created default clinic");

      // Associate existing users with the default clinic
      await client.query(`
        UPDATE users SET clinic_id = 'clinic_default' WHERE clinic_id IS NULL
      `);
      
      // Set the first doctor as the super admin
      await client.query(`
        UPDATE users 
        SET role = 'super_admin', is_primary = TRUE 
        WHERE id = (SELECT id FROM users WHERE role = 'doctor' ORDER BY id LIMIT 1)
      `);
    }

    // Commit transaction
    await client.query('COMMIT');
    console.log("Clinic management migration completed successfully");
    
    return { success: true, message: "Clinic management migration completed successfully" };
  } catch (error) {
    // Rollback transaction on error
    await client.query('ROLLBACK');
    console.error("Error during clinic management migration:", error);
    
    return { success: false, message: error.message, error };
  } finally {
    client.release();
  }
}

// Execute the migration if this is the main module
runMigration()
  .then(result => {
    if (result.success) {
      console.log(result.message);
      process.exit(0);
    } else {
      console.error("Migration failed:", result.message);
      process.exit(1);
    }
  })
  .catch(err => {
    console.error("Unexpected error during migration:", err);
    process.exit(1);
  });

// Export for imports
export { runMigration };