/**
 * Role-based Permission Middleware for Healthcare App
 * 
 * Implements HIPAA and GDPR compliant access controls for different user roles.
 */

const ROLES = {
  CLERK: 'clerk',
  NURSE: 'nurse', 
  DOCTOR: 'doctor',
  ADMIN: 'admin',
  SUPER_ADMIN: 'super_admin'
};

// Role access map: define which roles can access each endpoint category
const permissionsMap = {
  "/api/medical-records": [ROLES.DOCTOR, ROLES.NURSE, ROLES.SUPER_ADMIN],
  "/api/patient-results": [ROLES.DOCTOR, ROLES.NURSE, ROLES.SUPER_ADMIN],
  "/api/admin/billing": [ROLES.ADMIN],
  "/api/admin/audit-logs": [ROLES.ADMIN, ROLES.SUPER_ADMIN],
  "/api/clinic/settings": [ROLES.SUPER_ADMIN, ROLES.ADMIN],
  "/api/clinic/users": [ROLES.SUPER_ADMIN], // only super admin adds users
  "/api/patients": [ROLES.CLERK, ROLES.DOCTOR, ROLES.NURSE, ROLES.SUPER_ADMIN],
  "/api/appointments": [ROLES.CLERK, ROLES.DOCTOR, ROLES.NURSE, ROLES.SUPER_ADMIN],
};

// Resource types in the healthcare system
const RESOURCES = {
  PATIENT_BASIC: 'patient_basic',
  APPOINTMENTS: 'appointments',
  BILLING: 'billing',
  MEDICAL_RECORDS: 'medical_records',
  VITALS: 'vitals',
  DIAGNOSES: 'diagnoses',
  MEDICATIONS: 'medications',
  LAB_RESULTS: 'lab_results',
  MENTAL_HEALTH: 'mental_health',
  SEXUAL_HEALTH: 'sexual_health',
  SUBSTANCE_ABUSE: 'substance_abuse'
};

/**
 * Permission matrix defining what resources each role can access
 */
const rolePermissions = {
  [ROLES.CLERK]: [
    RESOURCES.PATIENT_BASIC,
    RESOURCES.APPOINTMENTS,
    RESOURCES.BILLING
  ],
  [ROLES.NURSE]: [
    RESOURCES.PATIENT_BASIC,
    RESOURCES.APPOINTMENTS,
    RESOURCES.BILLING,
    RESOURCES.MEDICAL_RECORDS,
    RESOURCES.VITALS,
    RESOURCES.DIAGNOSES,
    RESOURCES.MEDICATIONS,
    RESOURCES.LAB_RESULTS
  ],
  [ROLES.DOCTOR]: [
    RESOURCES.PATIENT_BASIC,
    RESOURCES.APPOINTMENTS,
    RESOURCES.BILLING,
    RESOURCES.MEDICAL_RECORDS,
    RESOURCES.VITALS,
    RESOURCES.DIAGNOSES,
    RESOURCES.MEDICATIONS,
    RESOURCES.LAB_RESULTS,
    RESOURCES.MENTAL_HEALTH,
    RESOURCES.SEXUAL_HEALTH,
    RESOURCES.SUBSTANCE_ABUSE
  ],
  [ROLES.ADMIN]: [
    RESOURCES.PATIENT_BASIC,
    RESOURCES.APPOINTMENTS,
    RESOURCES.BILLING,
    RESOURCES.VITALS
  ],
  [ROLES.SUPER_ADMIN]: [
    RESOURCES.PATIENT_BASIC,
    RESOURCES.APPOINTMENTS,
    RESOURCES.BILLING,
    RESOURCES.MEDICAL_RECORDS,
    RESOURCES.VITALS,
    RESOURCES.DIAGNOSES
  ]
};

/**
 * Middleware to enforce role-based access control
 */
function enforceRolePermissions(req, res, next) {
  const user = req.user;
  if (!user || !user.role) {
    return res.status(401).json({ 
      error: "Unauthorized",
      message: "User not authenticated" 
    });
  }

  // Match the path to a rule
  const matchedPath = Object.keys(permissionsMap).find(path => 
    req.path.startsWith(path)
  );

  if (matchedPath) {
    const allowedRoles = permissionsMap[matchedPath];
    if (!allowedRoles.includes(user.role)) {
      return res.status(403).json({
        error: "Forbidden",
        message: "You do not have permission to access this resource",
        requiredRoles: allowedRoles,
        yourRole: user.role
      });
    }
  }

  // Check resource-level permissions
  const resource = getResourceForEndpoint(req.path);
  if (resource && !hasPermission(user.role, resource)) {
    return res.status(403).json({
      error: "Forbidden",
      message: `${user.role} role is not authorized to access ${resource}`
    });
  }

  // Log access for audit trail (HIPAA requirement)
  const timestamp = new Date().toISOString();
  console.log(`[ACCESS LOG] ${timestamp} - User ${user.id} (${user.role}) accessed ${req.path}`);

  next();
}

/**
 * Check if a role has permission to access a resource
 */
function hasPermission(role, resource) {
  return rolePermissions[role] && rolePermissions[role].includes(resource);
}

/**
 * Get resource type for an endpoint
 */
function getResourceForEndpoint(path) {
  if (path.includes('/medical-records')) return RESOURCES.MEDICAL_RECORDS;
  if (path.includes('/appointments')) return RESOURCES.APPOINTMENTS;
  if (path.includes('/patients')) return RESOURCES.PATIENT_BASIC;
  if (path.includes('/billing')) return RESOURCES.BILLING;
  if (path.includes('/vitals')) return RESOURCES.VITALS;
  if (path.includes('/diagnoses')) return RESOURCES.DIAGNOSES;
  if (path.includes('/medications')) return RESOURCES.MEDICATIONS;
  if (path.includes('/lab-results')) return RESOURCES.LAB_RESULTS;
  if (path.includes('/mental-health')) return RESOURCES.MENTAL_HEALTH;
  if (path.includes('/sexual-health')) return RESOURCES.SEXUAL_HEALTH;
  if (path.includes('/substance-abuse')) return RESOURCES.SUBSTANCE_ABUSE;
  return null;
}

module.exports = {
  ROLES,
  RESOURCES,
  enforceRolePermissions,
  hasPermission,
  getResourceForEndpoint
};