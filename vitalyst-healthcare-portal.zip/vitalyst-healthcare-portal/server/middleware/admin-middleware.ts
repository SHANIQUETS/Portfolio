import { Request, Response, NextFunction } from "express";
import { storage } from "../storage";

// Utility function to check the direct login token (development only)
async function verifyAdminByToken(req: Request): Promise<boolean> {
  // Check if the direct login token header is present
  const token = req.headers['x-direct-login-token'];
  
  if (false) {
    // Check for admin1 hardcoded username token
    const adminId = req.headers['x-direct-login-userid'];
    
    if (adminId) {
      try {
        const user = await storage.getUser(Number(adminId));
        if (user && (user.role === 'admin' || user.role === 'super_admin')) {
          // Set the user on the request object for subsequent middleware
          req.user = user;
          return true;
        }
      } catch (error) {
        console.error('Error in direct token verification:', error);
      }
    }
  }
  
  return false;
}

/**
 * Middleware to check if the user is an admin or super admin
 * This protects routes that either role can access
 */
export const requireAdminOrSuperAdmin = async (req: Request, res: Response, next: NextFunction) => {
  // First check normal session authentication
  if (req.isAuthenticated() && req.user && 
      (req.user.role === 'super_admin' || req.user.role === 'admin')) {
    return next();
  }
  
  // If not authenticated via session, check for direct login token (development only)
  if (await verifyAdminByToken(req)) {
    console.log('Admin verified via direct login token');
    return next();
  }
  
  // Not authenticated at all
  if (!req.isAuthenticated()) {
    return res.status(401).json({ 
      error: "Unauthorized",
      message: "You must be logged in to access this resource" 
    });
  }
  
  // Authenticated but not admin
  return res.status(403).json({ 
    error: "Forbidden", 
    message: "This action requires admin privileges" 
  });
};

/**
 * Middleware to check if the user is a system admin only
 * This protects system-specific routes from clinic admins
 */
export const requireSystemAdmin = async (req: Request, res: Response, next: NextFunction) => {
  // First check normal session authentication
  if (req.isAuthenticated() && req.user && 
      (req.user.role === 'admin' || req.user.role === 'super_admin') && 
      req.user.entityType === 'platform_admin') {
    return next();
  }
  
  // If not authenticated via session, check for direct login token (development only)
  if (process.env.NODE_ENV === 'development' && await verifyAdminByToken(req)) {
    console.log('Admin verified via direct login token');
    // Re-check the specific role
    if (req.user && req.user.role === 'admin') {
      return next();
    }
  }
  
  // Not authenticated at all
  if (!req.isAuthenticated()) {
    return res.status(401).json({ 
      error: "Unauthorized",
      message: "You must be logged in to access this resource" 
    });
  }
  
  // Authenticated but not admin
  return res.status(403).json({ 
    error: "Forbidden", 
    message: "This action requires system admin privileges" 
  });
};

/**
 * Middleware to check if the user is a clinic super admin only
 * This protects clinic-specific routes from system admins
 */
export const requireClinicSuperAdmin = async (req: Request, res: Response, next: NextFunction) => {
  // First check normal session authentication
  if (req.isAuthenticated() && req.user && req.user.role === 'super_admin') {
    return next();
  }
  
  // If not authenticated via session, check for direct login token (development only)
  if (await verifyAdminByToken(req)) {
    console.log('Admin verified via direct login token');
    // Re-check the specific role
    if (req.user && req.user.role === 'super_admin') {
      return next();
    }
  }
  
  // Not authenticated at all
  if (!req.isAuthenticated()) {
    return res.status(401).json({ 
      error: "Unauthorized",
      message: "You must be logged in to access this resource" 
    });
  }
  
  // Authenticated but not super_admin
  return res.status(403).json({ 
    error: "Forbidden", 
    message: "This action requires clinic admin privileges" 
  });
};

// Keep the old name for backward compatibility
export const requireSuperAdmin = requireAdminOrSuperAdmin;