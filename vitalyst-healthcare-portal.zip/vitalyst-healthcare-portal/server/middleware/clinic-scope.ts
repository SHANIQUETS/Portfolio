
import { Request, Response, NextFunction } from 'express';

export const requireClinicScope = () => {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ 
        error: "Unauthorized",
        message: "You must be logged in to access this resource" 
      });
    }

    // Skip for system admins as they can access all clinics
    if (req.user.role === 'admin' && req.user.clinicId === 'system') {
      return next();
    }

    // Get clinicId from authenticated user
    const clinicId = req.user.clinicId;
    if (!clinicId) {
      return res.status(403).json({
        error: "Forbidden",
        message: "No clinic association found"
      });
    }

    // Attach clinicId to request query params
    req.query.clinicId = clinicId;
    
    // Also attach to a custom property for direct access
    req.clinicScope = clinicId;

    next();
  };
};
