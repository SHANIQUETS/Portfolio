import { Request, Response, NextFunction } from 'express';

/**
 * HIPAA and UK GDPR Compliant Permission System
 * 
 * This module implements role-based access control (RBAC) for healthcare data
 * ensuring compliance with HIPAA (Health Insurance Portability and Accountability Act)
 * and UK GDPR (General Data Protection Regulation) requirements.
 * 
 * The system restricts access based on:
 * 1. User role (clerk, nurse, doctor, admin)
 * 2. Data sensitivity category
 * 3. Operation type (read, write, delete)
 * 
 * Special attention is given to clerk restrictions as they should only access
 * administrative data and not clinical/medical information.
 */

// Define core data sensitivity categories
export enum DataCategory {
  // Low sensitivity - Generally accessible by all authenticated staff
  DEMOGRAPHICS = 'demographics',        // Basic patient identity information
  APPOINTMENTS = 'appointments',        // Scheduling information
  BILLING = 'billing',                  // Financial and insurance data
  
  // Medium sensitivity - Healthcare provider access required
  VITALS = 'vitals',                    // Basic health measurements
  MEDICATIONS = 'medications',          // Medication history and prescriptions
  ALLERGIES = 'allergies',              // Patient allergies
  
  // High sensitivity - Restricted to qualified medical staff
  MEDICAL_HISTORY = 'medical_history',  // Past and current medical conditions
  DIAGNOSES = 'diagnoses',              // Clinical diagnoses
  LAB_RESULTS = 'lab_results',          // Laboratory and test results
  TREATMENT_PLANS = 'treatment_plans',  // Therapeutic plans and procedures
  
  // Very high sensitivity - Tightest restrictions
  MENTAL_HEALTH = 'mental_health',      // Psychiatric and psychological data
  SUBSTANCE_ABUSE = 'substance_abuse',  // Addiction and drug use information
  SEXUAL_HEALTH = 'sexual_health',      // Sexual and reproductive health data
  GENETIC_INFO = 'genetic_info'         // Genetic testing and genomic data
}

// Define user roles with increasing privileges
export enum UserRole {
  CLERK = 'clerk',
  NURSE = 'nurse',
  DOCTOR = 'doctor',
  ADMIN = 'admin',
  SUPER_ADMIN = 'super_admin'
}

// Define operation types
export enum Operation {
  READ = 'read',
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete'
}

/**
 * Permission Matrix
 * Maps roles to the data categories they can access for each operation type
 * This matrix follows the principle of least privilege, granting only
 * the minimum necessary access for each role
 */
const permissionMatrix: Record<
  UserRole, 
  Record<Operation, DataCategory[]>
> = {
  // CLERK PERMISSIONS
  // Restricted to administrative data only, no clinical access
  [UserRole.CLERK]: {
    [Operation.READ]: [
      // Clerks can read basic patient information
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.BILLING,
      // Limited access to allergens for patient safety
      DataCategory.ALLERGIES,
      // Access to lab results and patient results
      DataCategory.LAB_RESULTS,
      DataCategory.PATIENT_RESULTS
    ],
    [Operation.CREATE]: [
      // Clerks can create and register patients
      DataCategory.DEMOGRAPHICS,
      // Clerks can schedule appointments
      DataCategory.APPOINTMENTS,
      // Clerks can enter billing information
      DataCategory.BILLING
    ],
    [Operation.UPDATE]: [
      // Clerks can update contact information
      DataCategory.DEMOGRAPHICS,
      // Clerks can reschedule appointments
      DataCategory.APPOINTMENTS,
      // Clerks can update billing/insurance info
      DataCategory.BILLING
    ],
    [Operation.DELETE]: [
      // Clerks generally don't delete data to maintain audit trail
      // Can only cancel appointments
      DataCategory.APPOINTMENTS
    ]
  },

  // NURSE PERMISSIONS
  // Access to most clinical data except most sensitive categories
  [UserRole.NURSE]: {
    [Operation.READ]: [
      // Nurses can read all general patient data
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.BILLING,
      // Nurses need access to clinical data for patient care
      DataCategory.VITALS,
      DataCategory.MEDICATIONS,
      DataCategory.ALLERGIES,
      DataCategory.MEDICAL_HISTORY,
      DataCategory.DIAGNOSES,
      DataCategory.LAB_RESULTS,
      DataCategory.TREATMENT_PLANS,
      // Limited mental health access for continuity of care
      DataCategory.MENTAL_HEALTH
    ],
    [Operation.CREATE]: [
      // Nurses can create most clinical records
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.VITALS,
      DataCategory.MEDICATIONS,
      DataCategory.ALLERGIES,
      DataCategory.MEDICAL_HISTORY,
      DataCategory.LAB_RESULTS
    ],
    [Operation.UPDATE]: [
      // Nurses can update most clinical data
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.VITALS,
      DataCategory.MEDICATIONS,
      DataCategory.ALLERGIES,
      DataCategory.MEDICAL_HISTORY,
      DataCategory.LAB_RESULTS
    ],
    [Operation.DELETE]: [
      // Nurses have limited deletion rights
      DataCategory.APPOINTMENTS,
      // Can cancel or void incorrect measurements
      DataCategory.VITALS,
      DataCategory.LAB_RESULTS
    ]
  },

  // DOCTOR PERMISSIONS
  // Comprehensive access to all clinical data
  [UserRole.DOCTOR]: {
    [Operation.READ]: [
      // Doctors can access all patient information
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.BILLING,
      DataCategory.VITALS,
      DataCategory.MEDICATIONS,
      DataCategory.ALLERGIES,
      DataCategory.MEDICAL_HISTORY,
      DataCategory.DIAGNOSES, 
      DataCategory.LAB_RESULTS,
      DataCategory.TREATMENT_PLANS,
      DataCategory.MENTAL_HEALTH,
      DataCategory.SUBSTANCE_ABUSE,
      DataCategory.SEXUAL_HEALTH,
      DataCategory.GENETIC_INFO
    ],
    [Operation.CREATE]: [
      // Doctors can create all clinical records
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.VITALS,
      DataCategory.MEDICATIONS,
      DataCategory.ALLERGIES,
      DataCategory.MEDICAL_HISTORY,
      DataCategory.DIAGNOSES,
      DataCategory.LAB_RESULTS,
      DataCategory.TREATMENT_PLANS,
      DataCategory.MENTAL_HEALTH,
      DataCategory.SUBSTANCE_ABUSE,
      DataCategory.SEXUAL_HEALTH,
      DataCategory.GENETIC_INFO
    ],
    [Operation.UPDATE]: [
      // Doctors can update all clinical records
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.VITALS,
      DataCategory.MEDICATIONS,
      DataCategory.ALLERGIES,
      DataCategory.MEDICAL_HISTORY,
      DataCategory.DIAGNOSES,
      DataCategory.LAB_RESULTS,
      DataCategory.TREATMENT_PLANS,
      DataCategory.MENTAL_HEALTH,
      DataCategory.SUBSTANCE_ABUSE,
      DataCategory.SEXUAL_HEALTH,
      DataCategory.GENETIC_INFO
    ],
    [Operation.DELETE]: [
      // Doctors have broader deletion rights but still limited
      // for audit and legal purposes
      DataCategory.APPOINTMENTS,
      DataCategory.MEDICATIONS,
      DataCategory.VITALS,
      DataCategory.LAB_RESULTS,
      DataCategory.TREATMENT_PLANS
    ]
  },

  // ADMIN PERMISSIONS
  // Focus on system management rather than clinical access
  [UserRole.ADMIN]: {
    [Operation.READ]: [
      // Admins can access administrative data
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.BILLING,
      // Limited clinical data access
      DataCategory.VITALS,
      DataCategory.MEDICATIONS,
      DataCategory.ALLERGIES
    ],
    [Operation.CREATE]: [
      // Admins can create administrative data
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.BILLING
    ],
    [Operation.UPDATE]: [
      // Admins can update administrative data
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.BILLING
    ],
    [Operation.DELETE]: [
      // Admins have broader deletion rights for system maintenance
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.BILLING
    ]
  },

  // SUPER ADMIN PERMISSIONS
  // Complete access to all system functionality
  [UserRole.SUPER_ADMIN]: {
    [Operation.READ]: [
      // Super admins can access all data categories
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.BILLING,
      DataCategory.VITALS,
      DataCategory.MEDICATIONS,
      DataCategory.ALLERGIES,
      DataCategory.MEDICAL_HISTORY,
      DataCategory.DIAGNOSES, 
      DataCategory.LAB_RESULTS,
      DataCategory.TREATMENT_PLANS,
      DataCategory.MENTAL_HEALTH,
      DataCategory.SUBSTANCE_ABUSE,
      DataCategory.SEXUAL_HEALTH,
      DataCategory.GENETIC_INFO
    ],
    [Operation.CREATE]: [
      // Super admins can create all data categories
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.BILLING,
      DataCategory.VITALS,
      DataCategory.MEDICATIONS,
      DataCategory.ALLERGIES,
      DataCategory.MEDICAL_HISTORY,
      DataCategory.DIAGNOSES, 
      DataCategory.LAB_RESULTS,
      DataCategory.TREATMENT_PLANS,
      DataCategory.MENTAL_HEALTH,
      DataCategory.SUBSTANCE_ABUSE,
      DataCategory.SEXUAL_HEALTH,
      DataCategory.GENETIC_INFO
    ],
    [Operation.UPDATE]: [
      // Super admins can update all data categories
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.BILLING,
      DataCategory.VITALS,
      DataCategory.MEDICATIONS,
      DataCategory.ALLERGIES,
      DataCategory.MEDICAL_HISTORY,
      DataCategory.DIAGNOSES, 
      DataCategory.LAB_RESULTS,
      DataCategory.TREATMENT_PLANS,
      DataCategory.MENTAL_HEALTH,
      DataCategory.SUBSTANCE_ABUSE,
      DataCategory.SEXUAL_HEALTH,
      DataCategory.GENETIC_INFO
    ],
    [Operation.DELETE]: [
      // Super admins can delete all data categories
      DataCategory.DEMOGRAPHICS,
      DataCategory.APPOINTMENTS,
      DataCategory.BILLING,
      DataCategory.VITALS,
      DataCategory.MEDICATIONS,
      DataCategory.ALLERGIES,
      DataCategory.MEDICAL_HISTORY,
      DataCategory.DIAGNOSES, 
      DataCategory.LAB_RESULTS,
      DataCategory.TREATMENT_PLANS,
      DataCategory.MENTAL_HEALTH,
      DataCategory.SUBSTANCE_ABUSE,
      DataCategory.SEXUAL_HEALTH,
      DataCategory.GENETIC_INFO
    ]
  }
};

/**
 * Map API endpoints to data categories for authorization purposes
 * This helps the permission middleware determine which data category
 * is being accessed by a particular API endpoint
 */
const endpointCategoryMap: Record<string, DataCategory> = {
  // Patient demographics endpoints
  '/api/patients': DataCategory.DEMOGRAPHICS,
  '/api/patients/lookup': DataCategory.DEMOGRAPHICS,
  '/api/patients/fuzzy-search': DataCategory.DEMOGRAPHICS,
  
  // Individual patient access - requires checking pattern
  // Handled by patternMatchers below
  
  // Appointment endpoints
  '/api/appointments': DataCategory.APPOINTMENTS,
  
  // Medical record endpoints
  '/api/records': DataCategory.MEDICAL_HISTORY,
  
  // Billing endpoints
  '/api/billing': DataCategory.BILLING,
  
  // User management endpoints - separate admin permission
  '/api/users': DataCategory.DEMOGRAPHICS,
  
  // Audit log endpoints - administrative
  '/api/audit-logs': DataCategory.DEMOGRAPHICS
};

/**
 * Pattern matchers for dynamic endpoints
 * For endpoints that include parameters (like IDs), we need pattern matching
 * rather than exact string matching
 */
const patternMatchers: Array<{
  pattern: RegExp,
  category: DataCategory
}> = [
  // Patient demographic details by ID
  { pattern: /^\/api\/patients\/\d+$/, category: DataCategory.DEMOGRAPHICS },
  
  // Patient medical records
  { pattern: /^\/api\/patients\/\d+\/records$/, category: DataCategory.MEDICAL_HISTORY },
  { pattern: /^\/api\/records\/\d+$/, category: DataCategory.MEDICAL_HISTORY },
  
  // Patient diagnostics results
  { pattern: /^\/api\/records\/\d+\/diagnostics$/, category: DataCategory.LAB_RESULTS },
  
  // Patient medications
  { pattern: /^\/api\/patients\/\d+\/medications$/, category: DataCategory.MEDICATIONS },
  
  // Patient appointments
  { pattern: /^\/api\/patients\/\d+\/appointments$/, category: DataCategory.APPOINTMENTS },
  { pattern: /^\/api\/appointments\/\d+$/, category: DataCategory.APPOINTMENTS },
  
  // Mental health records
  { pattern: /^\/api\/records\/\d+\/mental-health$/, category: DataCategory.MENTAL_HEALTH },
  
  // Sexual health records
  { pattern: /^\/api\/records\/\d+\/sexual-health$/, category: DataCategory.SEXUAL_HEALTH }
];

/**
 * Determine the data category for a given endpoint
 * @param endpoint The API endpoint path
 * @returns The data category or undefined if not mapped
 */
function getCategoryForEndpoint(endpoint: string): DataCategory | undefined {
  // Check direct mappings first
  if (endpointCategoryMap[endpoint]) {
    return endpointCategoryMap[endpoint];
  }
  
  // Check pattern matchers for dynamic endpoints
  for (const matcher of patternMatchers) {
    if (matcher.pattern.test(endpoint)) {
      return matcher.category;
    }
  }
  
  // No matching category found
  return undefined;
}

/**
 * Determine the operation type based on HTTP method
 * @param method The HTTP method of the request
 * @returns The corresponding operation type
 */
function getOperationFromMethod(method: string): Operation {
  switch (method.toUpperCase()) {
    case 'GET':
      return Operation.READ;
    case 'POST':
      return Operation.CREATE;
    case 'PUT':
    case 'PATCH':
      return Operation.UPDATE;
    case 'DELETE':
      return Operation.DELETE;
    default:
      return Operation.READ; // Default to READ for unknown methods
  }
}

/**
 * Check if a user has permission for a specific operation on a data category
 * @param role The user's role
 * @param operation The operation being performed
 * @param category The data category being accessed
 * @returns True if the user has permission, false otherwise
 */
export function hasPermission(
  role: UserRole,
  operation: Operation,
  category: DataCategory
): boolean {
  // Get the allowed categories for this role and operation
  const allowedCategories = permissionMatrix[role][operation];
  
  // Check if the category is in the allowed list
  return allowedCategories.includes(category);
}

/**
 * Express middleware to enforce RBAC permissions on API endpoints
 * This is the main authorization check used in route handlers
 */
export function checkPermission(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Get the user role from the authenticated session
  const userRole = req.user?.role as UserRole;
  
  // If no authenticated user or no role, deny access
  if (!userRole) {
    return res.status(401).json({
      message: 'Authentication required',
      error: 'No authenticated user session found'
    });
  }
  
  // Determine the operation from the HTTP method
  const operation = getOperationFromMethod(req.method);
  
  // Get the data category for this endpoint
  const category = getCategoryForEndpoint(req.path);
  
  // If the endpoint is not mapped to a category, allow access
  // This should be avoided by ensuring all endpoints are properly mapped
  if (!category) {
    // Log this as a potential security issue to be fixed
    console.warn(`Permission check: Unmapped endpoint ${req.path}`);
    return next();
  }
  
  // Check if the user's role has permission for this operation on this category
  if (hasPermission(userRole, operation, category)) {
    // Allow the request to proceed
    return next();
  }
  
  // If permission check fails, deny access with appropriate message
  return res.status(403).json({
    message: 'Access forbidden',
    error: `User with role ${userRole} does not have permission to ${operation} ${category} data`
  });
}

/**
 * Specific middleware for restricting clerks from accessing medical records
 * This provides an additional layer of protection for sensitive medical data
 */
export function restrictClerksFromMedicalRecords(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Get the user role from the authenticated session
  const userRole = req.user?.role as UserRole;
  
  // If user is not a clerk or there's no authenticated user, proceed
  if (!userRole || userRole !== UserRole.CLERK) {
    return next();
  }
  
  // Check if this is a medical record endpoint using pattern matching
  const isMedicalRecordEndpoint = (
    req.path.includes('/records') || 
    req.path.includes('/medical-history') ||
    /\/patients\/\d+\/records/.test(req.path)
  );
  
  // If this is a medical record endpoint, deny access
  if (isMedicalRecordEndpoint) {
    return res.status(403).json({
      message: 'Access forbidden',
      error: 'Clerks are not permitted to access detailed medical records under HIPAA and GDPR regulations'
    });
  }
  
  // Allow access to non-medical record endpoints
  return next();
}

/**
 * Middleware to log access to sensitive data for audit purposes
 * Required for HIPAA compliance and useful for detecting unauthorized access
 */
export function auditSensitiveDataAccess(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Get the category for this endpoint
  const category = getCategoryForEndpoint(req.path);
  
  // Define highly sensitive categories that require auditing
  const sensitiveCategoriesRequiringAudit = [
    DataCategory.MEDICAL_HISTORY,
    DataCategory.DIAGNOSES,
    DataCategory.MENTAL_HEALTH,
    DataCategory.SUBSTANCE_ABUSE,
    DataCategory.SEXUAL_HEALTH,
    DataCategory.GENETIC_INFO
  ];
  
  // If this is accessing a sensitive category, log the access
  if (category && sensitiveCategoriesRequiringAudit.includes(category)) {
    const userRole = req.user?.role as UserRole;
    const userId = req.user?.id;
    const operation = getOperationFromMethod(req.method);
    
    // In a real system, this would call an audit logging service
    console.log(`AUDIT: ${userId} (${userRole}) performed ${operation} on ${category} at ${new Date().toISOString()}`);
    
    // Consider implementing real-time alerts for certain high-risk access patterns
  }
  
  // Always continue to the next middleware
  return next();
}

/**
 * Helper function to check patient record access
 * Ensures a user can only access records they're permitted to view
 * @param patientId ID of the patient whose record is being accessed
 * @param userRole Role of the user attempting access
 * @param sensitiveSection Optional specific sensitive section being accessed
 * @returns Boolean indicating if access should be allowed
 */
export function canAccessPatientRecord(
  patientId: number,
  userRole: UserRole,
  sensitiveSection?: DataCategory
): boolean {
  // Clerks can only access demographics
  if (userRole === UserRole.CLERK) {
    return !sensitiveSection || sensitiveSection === DataCategory.DEMOGRAPHICS;
  }
  
  // Nurses can access most categories except the most sensitive
  if (userRole === UserRole.NURSE) {
    const restrictedForNurses = [
      DataCategory.SUBSTANCE_ABUSE,
      DataCategory.GENETIC_INFO,
      DataCategory.SEXUAL_HEALTH
    ];
    
    return !sensitiveSection || !restrictedForNurses.includes(sensitiveSection);
  }
  
  // Doctors can access everything
  if (userRole === UserRole.DOCTOR) {
    return true;
  }
  
  // Default to denying access if role doesn't match known patterns
  return false;
}

/**
 * Middleware to check if a user is a system admin
 * System admins have special privileges across the entire platform
 * @param req Express request object
 * @param res Express response object
 * @param next Express next function
 */
export function isSystemAdmin(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Check if user exists and has isSystemAdmin flag
  if (!req.user) {
    return res.status(401).json({
      message: 'Authentication required',
      error: 'No authenticated user session found'
    });
  }

  // Check if the user is a system admin by role
  if (req.user.role === 'super_admin') {
    // User is a system admin, allow access
    return next();
  }

  // User is not a system admin, deny access
  return res.status(403).json({
    message: 'Access forbidden',
    error: 'This action requires system administrator privileges'
  });
}

/**
 * Additional Notes:
 * 
 * 1. This permission system should be used alongside proper authentication.
 * 2. The middleware should be applied to all routes that access protected data.
 * 3. Regular security audits should be performed to ensure the permissions matrix
 *    accurately reflects current policy and legal requirements.
 * 4. For HIPAA compliance, ensure all PHI access is logged for audit purposes.
 * 5. For GDPR compliance, ensure data access respects patient consent settings.
 */