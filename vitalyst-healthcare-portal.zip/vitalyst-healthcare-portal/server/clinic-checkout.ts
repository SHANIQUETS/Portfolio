
import Stripe from "stripe";
import { Request, Response } from "express";
import { STRIPE_AMOUNT_IDS } from "../client/src/lib/constants";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: "2022-11-15",
});

export async function createClinicCheckoutSession(req: Request, res: Response) {
  if (!req.user || !req.user.clinicId) {
    return res.status(403).json({ message: "Unauthorized - No clinic association" });
  }

  const { tier } = req.body;
  if (!tier || !STRIPE_AMOUNT_IDS[tier]) {
    return res.status(400).json({ message: "Invalid subscription tier" });
  }

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      mode: "subscription",
      line_items: [
        {
          price: STRIPE_AMOUNT_IDS[tier],
          quantity: 1,
        },
      ],
      metadata: {
        clinicId: req.user.clinicId,
        tier: tier
      },
      success_url: `${req.protocol}://${req.get('host')}/billing/success`,
      cancel_url: `${req.protocol}://${req.get('host')}/billing/cancel`,
    });

    res.json({ url: session.url });
  } catch (error) {
    console.error("Error creating Stripe Checkout session:", error);
    res.status(500).json({ 
      message: "Error creating Stripe Checkout session",
      error: error instanceof Error ? error.message : String(error)
    });
  }
}
