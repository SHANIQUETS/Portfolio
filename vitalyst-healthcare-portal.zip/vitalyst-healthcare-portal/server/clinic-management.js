/**
 * Clinic Management Module
 * Handles clinic tier functionality, role limits, and user onboarding
 */

import { scrypt, randomBytes, timingSafeEqual } from 'crypto';
import { promisify } from 'util';
import * as stripeManager from './stripe-manager.js';

const scryptAsync = promisify(scrypt);

/**
 * Generate a unique ID - implementation will depend on your DB strategy
 * Using a simple timestamp + random number for demonstration
 */
function generateUniqueId() {
  return `clinic_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
}

/**
 * Hash password using scrypt
 * @param {string} password - Raw password to hash
 * @returns {Promise<string>} The hashed password
 */
async function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString("hex")}.${salt}`;
}

/**
 * Get user limits based on clinic tier
 * @param {string} tier - The clinic's tier
 * @returns {Object} Object containing role limits
 */
function getTierLimits(tier) {
  const limits = {
    sole_trader: { 
      doctor: 1,
      nurse: 1,
      clerk: 1,
      super_admin: 1,
      amount: 100
    },
    small_clinic: { 
      doctor: 2,
      nurse: 2,
      clerk: 2,
      super_admin: 1,
      amount: 150
    },
    standard_clinic: { 
      doctor: 3,
      nurse: 4,
      clerk: 3,
      super_admin: 1,
      amount: 200
    },
    enterprise: { 
      doctor: 999, // Effectively unlimited
      nurse: 999,
      clerk: 999,
      super_admin: 1,
      amount: 500, // Default amount for enterprise, will be overridden by customPrice when provided
      isCustomPrice: true
    },
    system: {
      doctor: 0,
      nurse: 0,
      clerk: 0,
      super_admin: 0,
      admin: 999, // System tier is specifically for platform admins
      amount: 0 // No charge for system administration
    }
  };
  
  return limits[tier] || limits.sole_trader;
}

/**
 * Onboard a new clinic
 * 
 * @param {Object} db - Database connection or storage interface
 * @param {Object} data - Clinic registration data
 */
async function onboardClinic(db, data) {
  const { name, tier, superAdminName, superAdminEmail, password, customPrice } = data;
  
  const client = await db.connect();
  try {
    // Start transaction
    await client.query('BEGIN');
    
    // Create clinic with appropriate user limits
    const clinicId = generateUniqueId();
    const userLimits = getTierLimits(tier);
    
    // Restrict entity_type to only be set by system admins
    // Default to "clinic" if not specified or if not from admin route
    
    // This enforces the restriction that only system admins can create platform_admin entities
    const entityType = (data.fromAdminContext === true && data.entityType) 
      ? data.entityType 
      : "clinic";
    
    // Set address if provided
    const address = data.address || null;
    
    const clinicResult = await client.query(`
      INSERT INTO clinics (id, name, tier, entity_type, address)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id, name, tier, created_at, entity_type, address
    `, [clinicId, name, tier, entityType, address]);
    
    const clinic = clinicResult.rows[0];
    
    // Create the super admin user
    const hashedPassword = await hashPassword(password);
    
    const userResult = await client.query(`
      INSERT INTO users (username, password, full_name, role, email, clinic_id, is_primary)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING id, username, full_name, role, email, clinic_id, is_primary
    `, [superAdminEmail, hashedPassword, superAdminName, 'super_admin', superAdminEmail, clinicId, true]);
    
    const user = userResult.rows[0];
    
    // Create a subscription record
    // If enterprise tier, use the custom amount if provided, otherwise use tier-based pricing
    const tierLimits = getTierLimits(tier);
    const amount = tier === 'enterprise' && data.customAmount ? data.customAmount : tierLimits.amount || 0;
    
    // Plan start date is current date if not specified
    const planStartDate = data.planStartDate ? new Date(data.planStartDate) : new Date();
    
    // Create a Stripe customer using our stripe-manager 
    const customer = await stripeManager.createCustomer({
      name: superAdminName,
      email: superAdminEmail,
      clinicId: clinicId
    });
    
    // Create a Stripe subscription
    const subscription = await stripeManager.createSubscription({
      customerId: customer.id,
      tier: tier,
      amount: amount
    });
    
    // Create subscription record with Stripe data
    await client.query(`
      INSERT INTO subscriptions (clinic_id, tier, amount, status, start_date, stripe_customer_id, stripe_subscription_id, is_custom_pricing)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING id
    `, [clinicId, tier, amount, 'active', planStartDate, customer.id, subscription.id, tier === 'enterprise']);
    
    // Commit transaction
    await client.query('COMMIT');
    
    // Send welcome email (placeholder for now)
    await sendWelcomeEmail({
      name: superAdminName,
      email: superAdminEmail,
      clinicName: name,
      clinicTier: tier
    });
    
    return {
      ...clinic,
      admin: user
    };
  } catch (error) {
    // Rollback transaction on error
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Create a new user, respecting the clinic's tier limits
 * 
 * @param {Object} db - Database connection or storage interface
 * @param {Object} requestingUser - The user making the request
 * @param {Object} newUserData - Information for the new user
 */
async function createUser(db, requestingUser, newUserData) {
  const { name, email, username, password, role } = newUserData;
  
  if (!requestingUser || (!requestingUser.clinic_id && !requestingUser.clinicId)) {
    throw new Error("Requesting user must be associated with a clinic");
  }
  
  // Only super_admin and admin roles can create users
  if (requestingUser.role !== 'super_admin' && requestingUser.role !== 'admin') {
    throw new Error("Only administrators can create users");
  }
  
  // Check if the requested role is valid
  const validRoles = ['super_admin', 'admin', 'doctor', 'nurse', 'clerk'];
  if (!validRoles.includes(role)) {
    throw new Error(`Invalid role: ${role}`);
  }
  
  // Only super_admin can create other super_admin users
  if (role === 'super_admin' && requestingUser.role !== 'super_admin') {
    throw new Error("Only super admins can create other super admin users");
  }
  
  const client = await db.connect();
  try {
    // Start transaction
    await client.query('BEGIN');
    
    // Get clinic information - support both clinic_id and clinicId properties
    const clinicId = requestingUser.clinic_id || requestingUser.clinicId;
    const clinicResult = await client.query(
      'SELECT * FROM clinics WHERE id = $1',
      [clinicId]
    );
    
    if (!clinicResult.rows.length) {
      throw new Error("Clinic not found");
    }
    
    const clinic = clinicResult.rows[0];
    
    // Check if the clinic has reached its role limit
    const userCountResult = await client.query(
      'SELECT COUNT(*) FROM users WHERE clinic_id = $1 AND role = $2',
      [clinic.id, role]
    );
    
    const currentCount = parseInt(userCountResult.rows[0].count);
    const tierLimits = getTierLimits(clinic.tier);
    const roleLimit = tierLimits[role];
    
    // Check if the limit has been reached
    if (currentCount >= roleLimit) {
      throw new Error(`User limit for role '${role}' has been reached (${currentCount}/${roleLimit}). Please upgrade your plan.`);
    }
    
    // Create the new user
    const hashedPassword = await hashPassword(password);
    
    const userResult = await client.query(`
      INSERT INTO users (username, password, full_name, role, email, clinic_id)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id, username, full_name, role, email, clinic_id
    `, [username, hashedPassword, name, role, email, clinic.id]);
    
    const newUser = userResult.rows[0];
    
    // Commit transaction
    await client.query('COMMIT');
    
    return newUser;
  } catch (error) {
    // Rollback transaction on error
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Grant temporary support access to a clinic
 * 
 * @param {Object} db - Database connection or storage interface
 * @param {string} superAdminId - ID of the super admin granting access
 * @param {string} supportUserId - ID of the support user 
 * @param {string} clinicId - ID of the clinic
 */
async function grantSupportAccess(db, superAdminId, supportUserId, clinicId) {
  const client = await db.connect();
  try {
    // Start transaction
    await client.query('BEGIN');
    
    // Calculate expiration time (24 hours from now)
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);
    
    // Revoke any existing access
    await client.query(
      'UPDATE support_access SET status = $1 WHERE support_user_id = $2 AND clinic_id = $3',
      ['expired', supportUserId, clinicId]
    );
    
    // Create new support access
    const result = await client.query(`
      INSERT INTO support_access (granted_by, support_user_id, clinic_id, expires_at)
      VALUES ($1, $2, $3, $4)
      RETURNING id, granted_by, support_user_id, clinic_id, status, granted_at, expires_at
    `, [superAdminId, supportUserId, clinicId, expiresAt]);
    
    const supportAccess = result.rows[0];
    
    // Commit transaction
    await client.query('COMMIT');
    
    return supportAccess;
  } catch (error) {
    // Rollback transaction on error
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Check if support has valid access to a clinic
 * 
 * @param {Object} db - Database connection or storage interface
 * @param {string} supportUserId - ID of the support user
 * @param {string} clinicId - ID of the clinic
 */
async function checkSupportAccess(db, supportUserId, clinicId) {
  const client = await db.connect();
  try {
    // First, expire any outdated access
    await client.query(`
      UPDATE support_access 
      SET status = 'expired' 
      WHERE expires_at < NOW() AND status = 'active'
    `);
    
    // Check if there's an active support access
    const result = await client.query(`
      SELECT * FROM support_access 
      WHERE support_user_id = $1 
      AND clinic_id = $2 
      AND status = 'active'
      AND expires_at > NOW()
    `, [supportUserId, clinicId]);
    
    // If there's at least one valid access record, return it
    if (result.rows.length > 0) {
      return result.rows[0];
    }
    
    // No valid access found
    return null;
  } catch (error) {
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Middleware to check if user can perform an action based on their role and clinic tier
 * 
 * @param {Object} db - Database connection or storage interface 
 * @param {string} userId - ID of the user attempting the action
 * @param {string} action - The action being attempted
 */
async function checkUserPermission(db, userId, action) {
  const client = await db.connect();
  try {
    // Get user information
    const userResult = await client.query(
      'SELECT * FROM users WHERE id = $1',
      [userId]
    );
    
    if (!userResult.rows.length) {
      throw new Error("User not found");
    }
    
    const user = userResult.rows[0];
    
    // Define permissions based on roles
    const permissions = {
      super_admin: ['manage_users', 'manage_clinic', 'view_audit_logs', 'manage_patients'],
      admin: ['manage_users', 'manage_patients'],
      doctor: ['view_medical_records', 'create_medical_records', 'manage_patients'],
      nurse: ['view_medical_records', 'create_medical_records', 'manage_patients'],
      clerk: ['manage_appointments', 'view_patients']
    };
    
    // Check if the user's role has permission for the action
    const rolePermissions = permissions[user.role] || [];
    
    if (rolePermissions.includes(action)) {
      return true;
    }
    
    // No permission
    return false;
  } catch (error) {
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Send welcome email to new clinic
 * This is a placeholder function - implement with your actual email service
 * 
 * @param {Object} user - The newly created admin user
 */
async function sendWelcomeEmail(user) {
  // This is a placeholder - implement with your email provider (e.g., SendGrid)
  console.log(`[EMAIL] Welcome to Vitalyst, ${user.name}! Your clinic ${user.clinicName} has been registered at the ${user.clinicTier} tier.`);
  return true;
}

export {
  onboardClinic,
  createUser,
  grantSupportAccess,
  checkSupportAccess as checkSupport,
  checkUserPermission
}

// Default export for backward compatibility
export default {
  onboardClinic,
  createUser,
  grantSupportAccess,
  checkSupport: checkSupportAccess,
  checkUserPermission
};