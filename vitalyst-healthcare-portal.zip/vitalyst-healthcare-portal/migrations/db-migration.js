#!/usr/bin/env node
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

// This script creates a new non-interactive migration to update the database
async function runMigration() {
  try {
    console.log('Dropping existing tables and recreating them with the latest schema...');
    
    // Note: In a production environment, you would want to use a proper migration
    // that preserves data, but for this development setup we're doing a fresh push
    const drizzlePush = await execPromise('npx drizzle-kit push --verbose');
    console.log(drizzlePush.stdout);
    
    console.log('Database schema update completed successfully');
  } catch (error) {
    console.error('Error during migration:', error);
    process.exit(1);
  }
}

runMigration();