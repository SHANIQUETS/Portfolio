/**
 * Migration script to create the platform_admins table
 * for Platform Admin System with Primary Owner
 */

import pkg from 'pg';
const { Pool } = pkg;
import dotenv from 'dotenv';

dotenv.config();

// Create a PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// Get admin1 user email for primary owner role
async function getAdmin1Email() {
  try {
    const result = await pool.query(
      `SELECT email FROM users WHERE username = 'admin1' LIMIT 1`
    );
    
    if (result.rows.length > 0) {
      return result.rows[0].email || 'admin1@example.com';
    }
    
    return 'admin1@example.com'; // Default fallback
  } catch (error) {
    console.error('Error getting admin1 email:', error);
    return 'admin1@example.com'; // Default fallback on error
  }
}

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Starting platform_admins table migration...');
    
    // Begin transaction
    await client.query('BEGIN');
    
    // Check if platform_admins table exists
    const tableExists = await client.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'platform_admins'
      );
    `);
    
    if (!tableExists.rows[0].exists) {
      console.log('Creating platform_admins table...');
      
      // Create the platform_admins table
      await client.query(`
        CREATE TABLE platform_admins (
          id TEXT PRIMARY KEY,
          email TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          "isPrimaryOwner" BOOLEAN NOT NULL DEFAULT false,
          "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        );
      `);
      
      console.log('platform_admins table created successfully');
      
      // Get admin1's email
      const adminEmail = await getAdmin1Email();
      console.log(`Using email for primary owner: ${adminEmail}`);
      
      // Insert the primary owner record
      await client.query(`
        INSERT INTO platform_admins (id, email, name, "isPrimaryOwner")
        VALUES ('admin1', $1, 'Platform Owner', true);
      `, [adminEmail]);
      
      console.log('Primary owner admin1 added as platform admin');
    } else {
      console.log('platform_admins table already exists');
      
      // Check if admin1 entry exists
      const adminExists = await client.query(`
        SELECT * FROM platform_admins WHERE id = 'admin1';
      `);
      
      if (adminExists.rows.length === 0) {
        // Get admin1's email
        const adminEmail = await getAdmin1Email();
        console.log(`Using email for primary owner: ${adminEmail}`);
        
        // Insert the primary owner record
        await client.query(`
          INSERT INTO platform_admins (id, email, name, "isPrimaryOwner")
          VALUES ('admin1', $1, 'Platform Owner', true);
        `, [adminEmail]);
        
        console.log('Primary owner admin1 added as platform admin');
      } else {
        console.log('admin1 platform admin record already exists');
        
        // Update email if admin1 user has one in the users table
        const adminEmail = await getAdmin1Email();
        if (adminEmail !== adminExists.rows[0].email) {
          await client.query(`
            UPDATE platform_admins 
            SET email = $1
            WHERE id = 'admin1';
          `, [adminEmail]);
          console.log(`Updated admin1 platform admin email to: ${adminEmail}`);
        }
      }
    }
    
    // Commit transaction
    await client.query('COMMIT');
    console.log('Platform admin migration completed successfully');
    
  } catch (error) {
    // Rollback transaction on error
    await client.query('ROLLBACK');
    console.error('Migration failed:', error);
    throw error;
  } finally {
    // Release client back to pool
    client.release();
  }
}

// Run the migration
runMigration()
  .then(() => {
    console.log('Migration complete, exiting...');
    pool.end();
  })
  .catch(err => {
    console.error('Migration error:', err);
    pool.end();
    process.exit(1);
  });