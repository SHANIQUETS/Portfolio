
import { pool } from './scripts/db-connector.js';

async function addClinicIdToAuditLogs() {
  const client = await pool.connect();
  
  try {
    console.log('Starting audit_logs migration...');
    
    // Add clinic_id column and foreign key constraint
    await client.query(`
      ALTER TABLE audit_logs 
      ADD COLUMN clinic_id TEXT REFERENCES clinics(id);
      
      -- Update existing records to associate with clinics based on user's clinic
      UPDATE audit_logs 
      SET clinic_id = users.clinic_id
      FROM users 
      WHERE audit_logs.user_id = users.id;
    `);

    console.log('✅ Migration complete: clinic_id column added to audit_logs');
  } catch (error) {
    console.error('❌ Error during audit_logs migration:', error);
    throw error;
  } finally {
    client.release();
  }
}

// Run migration
addClinicIdToAuditLogs()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error('Migration failed:', error);
    process.exit(1);
  });
