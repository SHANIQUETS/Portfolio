/**
 * Database migration script to add clinic_id column to appointments, medical_records, and patient_results tables
 */

import pkg from 'pg';
const { Pool } = pkg;
import dotenvPkg from 'dotenv';
const dotenv = dotenvPkg;

// Load environment variables
dotenv.config();

// Create a connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Starting migration to add clinic_id field to tables...');
    
    // Begin transaction
    await client.query('BEGIN');
    
    // Check if appointments table has clinic_id column
    const appointmentsCheck = await client.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'appointments' AND column_name = 'clinic_id'
    `);
    
    if (appointmentsCheck.rows.length === 0) {
      console.log('Adding clinic_id column to appointments table...');
      await client.query(`
        ALTER TABLE appointments 
        ADD COLUMN IF NOT EXISTS clinic_id TEXT,
        ADD CONSTRAINT fk_appointment_clinic
        FOREIGN KEY (clinic_id) 
        REFERENCES clinics(id)
        ON DELETE SET NULL
      `);
      console.log('clinic_id column added to appointments table');
    } else {
      console.log('appointments table already has clinic_id column.');
    }
    
    // Check if medical_records table has clinic_id column
    const medicalRecordsCheck = await client.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'medical_records' AND column_name = 'clinic_id'
    `);
    
    if (medicalRecordsCheck.rows.length === 0) {
      console.log('Adding clinic_id column to medical_records table...');
      await client.query(`
        ALTER TABLE medical_records 
        ADD COLUMN IF NOT EXISTS clinic_id TEXT,
        ADD CONSTRAINT fk_medical_record_clinic
        FOREIGN KEY (clinic_id) 
        REFERENCES clinics(id)
        ON DELETE SET NULL
      `);
      console.log('clinic_id column added to medical_records table');
    } else {
      console.log('medical_records table already has clinic_id column.');
    }
    
    // Check if patient_results table has clinic_id column
    const patientResultsCheck = await client.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'patient_results' AND column_name = 'clinic_id'
    `);
    
    if (patientResultsCheck.rows.length === 0) {
      console.log('Adding clinic_id column to patient_results table...');
      await client.query(`
        ALTER TABLE patient_results 
        ADD COLUMN IF NOT EXISTS clinic_id TEXT,
        ADD CONSTRAINT fk_patient_result_clinic
        FOREIGN KEY (clinic_id) 
        REFERENCES clinics(id)
        ON DELETE SET NULL
      `);
      console.log('clinic_id column added to patient_results table');
    } else {
      console.log('patient_results table already has clinic_id column.');
    }
    
    // Commit transaction
    await client.query('COMMIT');
    console.log('Migration completed successfully!');
    
  } catch (error) {
    // Rollback transaction in case of error
    await client.query('ROLLBACK');
    console.error('Migration failed:', error);
    throw error;
  } finally {
    // Release client
    client.release();
    await pool.end();
  }
}

// Run the migration
runMigration().catch(err => {
  console.error('Migration script failed:', err);
  process.exit(1);
});