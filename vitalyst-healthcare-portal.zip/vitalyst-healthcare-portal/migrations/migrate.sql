-- Drop existing tables to recreate them with updated schema
DROP TABLE IF EXISTS medical_records;
DROP TABLE IF EXISTS patients;
DROP TABLE IF EXISTS users;

-- Recreate users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    full_name TEXT NOT NULL,
    specialization TEXT,
    email TEXT
);

-- Recreate patients table with all fields from the schema
CREATE TABLE IF NOT EXISTS patients (
    id SERIAL PRIMARY KEY,
    patient_id TEXT NOT NULL UNIQUE,
    birth_certificate_number TEXT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    date_of_birth TEXT NOT NULL,
    gender TEXT NOT NULL,
    occupation TEXT,
    marital_status TEXT,
    organ_donor_status TEXT,
    blood_type TEXT,
    primary_physician_name TEXT,
    
    -- Contact information
    email TEXT,
    phone TEXT,
    
    -- Address fields
    address_line1 TEXT,
    city TEXT,
    parish TEXT,
    country TEXT,
    
    -- Physical measurements
    height TEXT,
    weight TEXT,
    
    -- Emergency contact
    emergency_contact_name TEXT,
    emergency_contact_relationship TEXT,
    emergency_contact_phone TEXT,
    
    -- Insurance information
    insurance_provider TEXT,
    insurance_policy_number TEXT,
    insurance_group_number TEXT,
    insurance_contact_number TEXT
);

-- Recreate medical_records table
CREATE TABLE IF NOT EXISTS medical_records (
    id SERIAL PRIMARY KEY,
    patient_id INTEGER NOT NULL,
    doctor_id INTEGER NOT NULL,
    visit_date TEXT NOT NULL,
    visit_type TEXT NOT NULL,
    chief_complaint TEXT,
    allergies TEXT,
    current_medications TEXT,
    chronic_conditions TEXT,
    past_surgeries TEXT,
    family_history TEXT,
    social_history TEXT,
    sexual_history TEXT,
    preventive_care TEXT,
    vitals TEXT,
    examination_notes TEXT,
    diagnosis TEXT,
    treatment_plan TEXT,
    follow_up_plan TEXT
);

-- Create a test doctor account if one doesn't exist
INSERT INTO users (username, password, full_name, specialization, email)
VALUES ('Doctor Edwards', 'cce5ffe92c0022fc3d09a290c582f8c0e19a99aad9db4899731dfc4fc379d9fd.8f4c553c1f16538ced8f3e8eaf6ae76c', 'Dr. James Edwards', 'General Practice', 'doctor@example.com')
ON CONFLICT (username) DO NOTHING;