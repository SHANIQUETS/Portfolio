
import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import * as schema from './shared/schema.js';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function backfillAuditLogs(): Promise<void> {
  console.log('Starting audit logs backfill migration...');
  
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const result = await client.query(`
      UPDATE audit_logs
      SET clinic_id = users.clinic_id
      FROM users
      WHERE audit_logs.user_id = users.id
        AND audit_logs.clinic_id IS NULL;
    `);

    console.log(`Updated ${result.rowCount} audit log entries with clinic_id`);
    await client.query('COMMIT');
    console.log('Migration completed successfully');
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Migration failed:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

backfillAuditLogs().catch((err) => {
  console.error('Unhandled migration error:', err);
  process.exit(1);
});
