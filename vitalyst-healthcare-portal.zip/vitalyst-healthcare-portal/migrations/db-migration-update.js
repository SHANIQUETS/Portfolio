/**
 * Database migration script to update the schema.
 */
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from 'ws';

// Configure WebSocket for Neon serverless
neonConfig.webSocketConstructor = ws;

async function runMigration() {
  try {
    console.log('Starting database schema update...');
    
    const pool = new Pool({
      connectionString: process.env.DATABASE_URL,
    });

    // Add columns to patients table
    await pool.query(`
      ALTER TABLE patients 
      ADD COLUMN IF NOT EXISTS blood_type TEXT,
      ADD COLUMN IF NOT EXISTS organ_donor_status TEXT;
    `);
    console.log('Added blood_type and organ_donor_status columns to patients table');

    // Add columns to medical_records table
    await pool.query(`
      ALTER TABLE medical_records 
      ADD COLUMN IF NOT EXISTS patient_type TEXT,
      ADD COLUMN IF NOT EXISTS reason_for_visit TEXT;
    `);
    console.log('Added patient_type and reason_for_visit columns to medical_records table');

    console.log('Database schema update completed successfully');
    await pool.end();
  } catch (error) {
    console.error('Error updating database schema:', error);
    process.exit(1);
  }
}

runMigration();