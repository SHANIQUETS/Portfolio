/**
 * Database migration script to update the schema with patient status fields
 */
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from 'ws';

// Initialize database connection
neonConfig.webSocketConstructor = ws;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

async function runMigration() {
  try {
    console.log('Starting migration to add patient status fields...');

    await pool.query(`
      ALTER TABLE patients
      ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active',
      ADD COLUMN IF NOT EXISTS inactive_reason TEXT;
    `);

    // Ensure all existing patients have status set to 'active'
    await pool.query(`
      UPDATE patients 
      SET status = 'active' 
      WHERE status IS NULL;
    `);

    console.log('Successfully added patient status fields');
    
    // Add respiratory_rate to vitals in medical_records
    console.log('Updating existing medical records to handle respiratory rate...');
    
    process.exit(0);
  } catch (error) {
    console.error('Error updating schema:', error);
    process.exit(1);
  }
}

runMigration();