/**
 * Database migration script to add the patient_results table
 */
import pkg from 'pg';
const { Pool } = pkg;

async function runMigration() {
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
  });

  try {
    console.log('Starting migration to add patient_results table...');
    
    // Create the patient_results table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS patient_results (
        id SERIAL PRIMARY KEY,
        patient_id INTEGER NOT NULL REFERENCES patients(id),
        doctor_id INTEGER NOT NULL REFERENCES users(id),
        test_date TIMESTAMP NOT NULL,
        test_name TEXT NOT NULL,
        test_type TEXT NOT NULL,
        result_summary TEXT NOT NULL,
        result_details TEXT,
        normal_range TEXT,
        abnormal_flag BOOLEAN DEFAULT false,
        units TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        notes TEXT,
        attachment_url TEXT,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);
    
    console.log('Successfully created patient_results table');
    
    // Close the database connection
    await pool.end();
    console.log('Migration completed successfully.');
  } catch (error) {
    console.error('Error during migration:', error);
    process.exit(1);
  }
}

runMigration();