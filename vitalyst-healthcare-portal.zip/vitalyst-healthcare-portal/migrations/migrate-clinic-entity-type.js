/**
 * Migration script to add the entity_type column to the clinics table
 * and update the system admin entry to be of type platform_admin
 * 
 * Using direct PostgreSQL queries
 */
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from 'ws';

// Configure WebSockets for NeonDB
neonConfig.webSocketConstructor = ws;

async function runMigration() {
  // Create connection pool
  const pool = new Pool({ 
    connectionString: process.env.DATABASE_URL
  });
  
  try {
    console.log('Starting migration to add entity_type column and update system admin entry...');
    
    // First check if the entity_type column exists
    const columnCheck = await pool.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'clinics' AND column_name = 'entity_type'
    `);
    
    // Add the column if it doesn't exist
    if (columnCheck.rows.length === 0) {
      console.log('Adding entity_type column to clinics table...');
      await pool.query(`
        ALTER TABLE clinics 
        ADD COLUMN entity_type TEXT DEFAULT 'clinic'
      `);
    } else {
      console.log('entity_type column already exists');
    }
    
    // Check if system admin entry exists
    const systemCheck = await pool.query(`
      SELECT * FROM clinics WHERE id = 'system'
    `);
    
    if (systemCheck.rows.length === 0) {
      console.log('System admin entry not found, creating it...');
      
      // Create the system admin entry
      const result = await pool.query(`
        INSERT INTO clinics (id, name, tier, entity_type, status)
        VALUES ('system', 'Platform Administration', 'enterprise', 'platform_admin', 'active')
        RETURNING *
      `);
      
      console.log('Created system admin entry:', result.rows[0]);
    } else {
      console.log('System admin entry found, updating to platform_admin type...');
      
      // Update the existing system admin entry
      const result = await pool.query(`
        UPDATE clinics 
        SET entity_type = 'platform_admin', name = 'Platform Administration'
        WHERE id = 'system'
        RETURNING *
      `);
      
      console.log('Updated system admin entry:', result.rows[0]);
    }
    
    // Ensure all other clinics have entityType set to "clinic"
    await pool.query(`
      UPDATE clinics
      SET entity_type = 'clinic'
      WHERE id != 'system' AND (entity_type IS NULL OR entity_type = '')
    `);
    
    console.log('Migration completed successfully');
  } catch (error) {
    console.error('Migration failed:', error);
  } finally {
    await pool.end();
  }
}

runMigration().catch(console.error);