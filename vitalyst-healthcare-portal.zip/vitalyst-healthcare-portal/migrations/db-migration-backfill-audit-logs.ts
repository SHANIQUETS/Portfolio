
import { Pool } from '@neondatabase/serverless';
import { db } from './server/db';
import * as schema from './shared/schema';

async function backfillAuditLogs(): Promise<void> {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const client = await pool.connect();

  try {
    console.log('Starting audit logs backfill migration...');

    await client.query('BEGIN');

    // First update audit logs where user exists
    const userResult = await client.query(`
      UPDATE audit_logs
      SET clinic_id = users.clinic_id
      FROM users
      WHERE audit_logs.user_id = users.id
        AND audit_logs.clinic_id IS NULL
      RETURNING id;
    `);

    console.log(`Updated ${userResult.rowCount} audit logs with clinic_id from users`);

    // Then update any system-level audit logs to use default clinic
    const systemResult = await client.query(`
      UPDATE audit_logs 
      SET clinic_id = (SELECT id FROM clinics WHERE entity_type = 'platform_admin' LIMIT 1)
      WHERE clinic_id IS NULL
      RETURNING id;
    `);

    console.log(`Updated ${systemResult.rowCount} system-level audit logs`);

    await client.query('COMMIT');
    console.log('Migration completed successfully');
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Migration failed:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

backfillAuditLogs().catch((err) => {
  console.error('Unhandled migration error:', err);
  process.exit(1);
});
