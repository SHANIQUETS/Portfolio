import { Patient } from "./schema";

// Type for potential duplicate result
export interface PotentialDuplicate {
  patient: Patient;
  score: number;
  matchedOn: string[];
}