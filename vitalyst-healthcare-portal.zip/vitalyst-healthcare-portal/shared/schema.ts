import { pgTable, text, serial, integer, boolean, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("clerk"), // "clerk", "nurse", "doctor", "admin", "super_admin"
  specialization: text("specialization"),
  email: text("email"),
  clinicId: text("clinic_id"), // Reference to the clinic this user belongs to
  isPrimary: boolean("is_primary").default(false), // Whether this user is the primary admin for a clinic
  mustChangePassword: boolean("must_change_password").default(true), // Whether user must change password on next login
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  role: true,
  specialization: true,
  email: true,
});

export const patients = pgTable("patients", {
  id: serial("id").primaryKey(),
  patientId: text("patient_id").notNull().unique(),
  birthCertificateNumber: text("birth_certificate_number"),
  firstName: text("first_name").notNull(),
  middleName: text("middle_name"),
  lastName: text("last_name").notNull(),
  dateOfBirth: text("date_of_birth").notNull(),
  gender: text("gender").notNull(),
  occupation: text("occupation"),
  maritalStatus: text("marital_status"),
  primaryPhysicianName: text("primary_physician_name"),
  
  // Clinic association
  clinicId: text("clinic_id"), // Reference to the clinic this patient belongs to
  
  // Patient status
  status: text("status").default("active"), // "active" or "inactive"
  inactiveReason: text("inactive_reason"), // Reason for inactivation, if applicable
  
  // Contact information
  email: text("email"),
  phone: text("phone"),
  
  // Address fields
  addressLine1: text("address_line1"),
  city: text("city"),
  parish: text("parish"),
  country: text("country"),
  
  // Physical measurements
  height: text("height"),
  weight: text("weight"),
  
  // Medical information
  bloodType: text("blood_type"),
  organDonorStatus: text("organ_donor_status"),
  
  // Emergency contact
  emergencyContactName: text("emergency_contact_name"),
  emergencyContactRelationship: text("emergency_contact_relationship"),
  emergencyContactPhone: text("emergency_contact_phone"),
  
  // Insurance information
  insuranceProvider: text("insurance_provider"),
  insurancePolicyNumber: text("insurance_policy_number"),
  insuranceGroupNumber: text("insurance_group_number"),
  insuranceContactNumber: text("insurance_contact_number"),
});

export const insertPatientSchema = createInsertSchema(patients).omit({
  id: true,
});

export const medicalRecords = pgTable("medical_records", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  doctorId: integer("doctor_id").notNull(),
  clinicId: text("clinic_id"), // Reference to the clinic this medical record belongs to
  visitDate: text("visit_date").notNull(),
  visitType: text("visit_type").notNull(), // checkup, consultation, followup, etc.
  patientType: text("patient_type"), // New Patient, Consultation, etc.
  reasonForVisit: text("reason_for_visit"),
  chiefComplaint: text("chief_complaint"),
  allergies: text("allergies"),
  currentMedications: text("current_medications"),
  chronicConditions: text("chronic_conditions"),
  pastSurgeries: text("past_surgeries"),
  familyHistory: text("family_history"),
  socialHistory: text("social_history"),
  sexualHistory: text("sexual_history"),
  preventiveCare: text("preventive_care"),
  vitals: text("vitals"),
  examinationNotes: text("examination_notes"),
  diagnosis: text("diagnosis"),
  treatmentPlan: text("treatment_plan"),
  followUpPlan: text("follow_up_plan"),
});

export const insertMedicalRecordSchema = createInsertSchema(medicalRecords).omit({
  id: true,
});

// Add appointments table
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull().references(() => patients.id),
  doctorId: integer("doctor_id").notNull().references(() => users.id),
  clinicId: text("clinic_id"), // Reference to the clinic this appointment belongs to
  appointmentDate: timestamp("appointment_date").notNull(),
  appointmentTime: text("appointment_time").notNull(),
  duration: integer("duration").notNull().default(30), // Duration in minutes
  reason: text("reason"),
  status: text("status").notNull().default('scheduled'),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Create a modified insert schema with custom validation and transforms for date handling
export const insertAppointmentSchema = createInsertSchema(appointments)
  .omit({
    id: true,
    createdAt: true
  })
  .extend({
    // Override the appointmentDate field to accept both Date objects and ISO strings
    appointmentDate: z.preprocess(
      (arg) => {
        if (arg instanceof Date) return arg;
        if (typeof arg === 'string') {
          const date = new Date(arg);
          if (!isNaN(date.getTime())) return date;
        }
        return arg; // Let Zod handle the validation error
      },
      z.date({
        required_error: "Appointment date is required",
        invalid_type_error: "Appointment date must be a valid date"
      })
    )
  });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertPatient = z.infer<typeof insertPatientSchema>;
export type Patient = typeof patients.$inferSelect;

export type InsertMedicalRecord = z.infer<typeof insertMedicalRecordSchema>;
export type MedicalRecord = typeof medicalRecords.$inferSelect;

export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;

// Add audit logs table
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(), // patient, medical_record, appointment, etc.
  entityId: integer("entity_id"),
  details: text("details"), // Additional details in JSON format
  ipAddress: text("ip_address"),
  timestamp: timestamp("timestamp").defaultNow(),
  clinicId: text("clinic_id"), // Reference to the clinic this audit log belongs to
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  timestamp: true
});

export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
export interface AuditLogWithUsername extends AuditLog {
  username?: string;
}

// Add patient results table
export const patientResults = pgTable("patient_results", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull().references(() => patients.id),
  doctorId: integer("doctor_id").notNull().references(() => users.id),
  clinicId: text("clinic_id"), // Reference to the clinic this result belongs to
  testDate: timestamp("test_date").notNull(),
  testName: text("test_name").notNull(),
  testType: text("test_type").notNull().default("other"),

  // Keep result_summary since it's required in the database but we won't show it in the UI
  resultSummary: text("result_summary").notNull().default("No summary provided"),
  
  resultDetails: text("result_details"),
  normalRange: text("normal_range"),
  abnormalFlag: boolean("abnormal_flag").default(false),
  units: text("units"),
  status: text("status").notNull().default("pending"),
  notes: text("notes"),
  attachmentUrl: text("attachment_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPatientResultSchema = createInsertSchema(patientResults).omit({
  id: true,
  createdAt: true,
}).extend({
  testDate: z.preprocess(
    (arg) => {
      if (arg instanceof Date) return arg;
      if (typeof arg === 'string') {
        const date = new Date(arg);
        if (!isNaN(date.getTime())) return date;
      }
      return arg; // Let Zod handle the validation error
    },
    z.date({
      required_error: "Test date is required",
      invalid_type_error: "Test date must be a valid date"
    })
  ),
  // No additional fields
});

export type InsertPatientResult = z.infer<typeof insertPatientResultSchema>;
export type PatientResult = typeof patientResults.$inferSelect;

// Add clinics table - simplified to match exact database structure
export const clinics = pgTable("clinics", {
  id: text("id").primaryKey(), // Clinic identifier
  name: text("name").notNull(),
  tier: text("tier").notNull().default("standard"), // basic, standard, premium, etc.
  address: text("address"),
  createdAt: timestamp("created_at").defaultNow(),
  status: text("status").default("active"),
  entityType: text("entity_type").default("clinic"), // "clinic" or "platform_admin"
});

export const insertClinicSchema = createInsertSchema(clinics).omit({
  createdAt: true,
  status: true,
  // Don't omit entityType - we need it for platform_admin vs clinic distinction
});

export type InsertClinic = z.infer<typeof insertClinicSchema>;
export type Clinic = typeof clinics.$inferSelect;

// Add subscriptions table
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  clinicId: text("clinic_id").notNull().references(() => clinics.id),
  tier: text("tier").notNull(),
  amount: real("amount"), // Price in USD
  isCustomPricing: boolean("is_custom_pricing").default(false),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  status: text("status").notNull().default("active"), // active, canceled, suspended
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true
}).extend({
  startDate: z.preprocess(
    (arg) => {
      if (arg instanceof Date) return arg;
      if (typeof arg === 'string') {
        const date = new Date(arg);
        if (!isNaN(date.getTime())) return date;
      }
      return arg; // Let Zod handle the validation error
    },
    z.date({
      required_error: "Start date is required",
      invalid_type_error: "Start date must be a valid date"
    })
  ),
  endDate: z.preprocess(
    (arg) => {
      if (arg === null || arg === undefined) return undefined;
      if (arg instanceof Date) return arg;
      if (typeof arg === 'string') {
        const date = new Date(arg);
        if (!isNaN(date.getTime())) return date;
      }
      return arg; // Let Zod handle the validation error
    },
    z.date({
      invalid_type_error: "End date must be a valid date"
    }).optional()
  )
});

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

// Invoices table for billing management
export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull().unique(),
  clinicId: text("clinic_id").notNull().references(() => clinics.id),
  subscriptionId: integer("subscription_id").references(() => subscriptions.id),
  amount: real("amount").notNull(),
  description: text("description"),
  status: text("status").notNull().default("draft"), // draft, sent, paid, overdue, cancelled
  dueDate: timestamp("due_date").notNull(),
  issuedDate: timestamp("issued_date").notNull(),
  paidDate: timestamp("paid_date"),
  paymentMethod: text("payment_method"),
  paymentLink: text("payment_link"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  dueDate: z.preprocess(
    (arg) => {
      if (arg instanceof Date) return arg;
      if (typeof arg === 'string') {
        const date = new Date(arg);
        if (!isNaN(date.getTime())) return date;
      }
      return arg; // Let Zod handle the validation error
    },
    z.date({
      required_error: "Due date is required",
      invalid_type_error: "Due date must be a valid date"
    })
  ),
  issuedDate: z.preprocess(
    (arg) => {
      if (arg instanceof Date) return arg;
      if (typeof arg === 'string') {
        const date = new Date(arg);
        if (!isNaN(date.getTime())) return date;
      }
      return arg; // Let Zod handle the validation error
    },
    z.date({
      required_error: "Issued date is required",
      invalid_type_error: "Issued date must be a valid date"
    })
  ),
  paidDate: z.preprocess(
    (arg) => {
      if (arg === null || arg === undefined) return undefined;
      if (arg instanceof Date) return arg;
      if (typeof arg === 'string') {
        const date = new Date(arg);
        if (!isNaN(date.getTime())) return date;
      }
      return arg; // Let Zod handle the validation error
    },
    z.date({
      invalid_type_error: "Paid date must be a valid date"
    }).optional()
  )
});

export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoices.$inferSelect;

// Platform Admins table for Platform Admin System with Primary Owner
export const platformAdmins = pgTable("platform_admins", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name"),
  isPrimaryOwner: boolean("is_primary_owner").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const insertPlatformAdminSchema = createInsertSchema(platformAdmins).omit({
  createdAt: true,
});

export type InsertPlatformAdmin = z.infer<typeof insertPlatformAdminSchema>;
export type PlatformAdmin = typeof platformAdmins.$inferSelect;
