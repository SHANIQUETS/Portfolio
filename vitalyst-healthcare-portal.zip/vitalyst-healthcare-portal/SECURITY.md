# Security and privacy notice

Vitalyst is an archived prototype and has not undergone a formal healthcare security, privacy or penetration assessment.

## Do not

- Upload real patient records, identity documents or clinical documents.
- Deploy this repository as a live EHR without a complete security and regulatory redesign.
- Treat comments that mention HIPAA or UK GDPR as evidence of compliance.

## Changes made during public reconstruction

- Excluded the original `uploads/` directory and temporary files.
- Excluded cookie and local Replit configuration files.
- Excluded scripts containing fixed development usernames or passwords.
- Removed development direct-login and local-storage authentication bypass behaviour.
- Required `SESSION_SECRET` instead of using a source-code fallback.
- Added `.env.example`; real secrets must remain outside version control.

A production redesign would still require threat modelling, secure identity and access management, encryption/key management, audit review, retention policies, consent handling, clinical safety review and jurisdiction-specific legal assessment.
